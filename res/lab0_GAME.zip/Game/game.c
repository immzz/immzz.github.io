#include "game.h"

#include "images/font.dat"
#include "images/marks.dat"
#include "images/football.dat"
#include "images/player.dat"



#include "images/playground.dat"

#define resolution_y 320
#define resolution_x 200
#define resolution 64000
#define ZERO 1e-6
#define MAXINT 2147483647
#define FRAME_INTERVAL 2
//i tried to use enum to describe player status but failed
//so i have to define them here
#define PLAYER_STAND 0
#define PLAYER_RUN 1
#define PLAYER_PASS 2
#define PLAYER_LOB 3
#define PLAYER_THROW 4
#define PLAYER_FALLREC 5
#define PLAYER_TACKLE 6
#define PLAYER_SHOOT 7//the action is the same with lob
#define PLAYER_THROUGHPASS 8//the action is the same with pass
#define PLAYER_NONE 100
//same as directions
#define DIRE_UP 0
#define DIRE_DOWN 1
#define DIRE_LEFT 2
#define DIRE_RIGHT 3
//define KEY
//i borrowed some concept from actionscript
#define KEY_W 0x11//W correct
#define KEY_S 0x1f//S correct
#define KEY_A 0x1e//A correct
#define KEY_D 0x20//D correct
#define KEY_Q 0x10//Q correct
#define KEY_E 0x12//E correct
#define KEY_UP 72//correct
#define KEY_DOWN 80//correct
#define KEY_LEFT 75//correct
#define KEY_RIGHT 77//correct
//some physical consts
#define AIR_FRICTION 0.03
#define GROUND_FRICTION 0.06
#define GRAVITY 9.8
#define SPEED_DOWN_RATE 1
//some game consts
#define DRIBBLE_DISTANCE 8
#define DRIBBLE_DISTANCE_SQUARE 64
#define CHARGE_SPEED 8
#define SIDE_ALLY 0
#define SIDE_OPPO 1
#define DOOR_UP 0
#define DOOR_UP_LEFT  214
#define DOOR_UP_RIGHT 384
#define DOOR_DOWN 804
#define DOOR_DOWN_LEFT 212
#define DOOR_DOWN_RIGHT 384
#define ROLE_GK 0
#define ROLE_LB 1
#define ROLE_RB 2
#define ROLE_CB 3
#define ROLE_CM 4
#define ROLE_CDM 5
#define ROLE_CAM 6
#define ROLE_LM 7
#define ROLE_RM 8
#define ROLE_CF 9
#define ROLE_ST 10

#define TASK_NONE 0
#define TASK_MARK 1
#define TASK_BACKOFF 2
#define TASK_FORWARDRUN 3
#define TASK_GETBALL 4
#define TASK_TACKLE 5
#define TASK_PASS 6
#define TASK_SHOOT 7
#define TASK_ADJUST 8
#define TASK_PUSHLINE 9
#define TYPE_PLAYER 0
#define TYPE_BALL 1
#define TYPE_DOOR 2
#define TEAM_MANCHESTER 0
#define TEAM_CHELSEA 1
#define TEAM_MILAN 2
#define TEAM_INTER 3
#define TEAM_BARCELONA 4
#define TEAM_BAYERN 5
#define TEAM_COUNT 6
#define AI_INTERVAL 20
#define THREAT_TRIGGER -100
#define LONGPASS_TRIGGER 188.6796//sqrt(100*100+160*160)
#define TACKLE_TRIGGER 0
#define TACKLE_RANGE_SQUARE 225
#define ARRIVE_RANGEX 5
#define ARRIVE_RANGEY 5
#define HEIGHT_PLAYER_REACHABLE 4
#define HEIGHT_DOOR_REACHABLE 6
#define SPEED_PLAYER_CATCHABLE 5//5
#define SHOOT_RANGE 200
#define BASE_NORMAL 0
#define BASE_FORWARD 1
#define BASE_PUSH 2
#define MARK_RANGE_SQUARE 8100
#define MARK_RANGE 90
#define RUN_TRIGGER 20

#define BALL_NORMAL 0
#define BALL_OUT_UP_LEFT 1
#define BALL_OUT_UP_RIGHT 2
#define BALL_OUT_DOWN_LEFT 3
#define BALL_OUT_DOWN_RIGHT 4
#define BALL_OUT_LEFT 5
#define BALL_OUT_RIGHT 6
#define BALL_GOAL_UP 7
#define BALL_GOAL_DOWN 8
#define RESET_CORNER_UP_LEFT 0
#define RESET_CORNER_UP_RIGHT 1
#define RESET_CORNER_DOWN_LEFT 2
#define RESET_CORNER_DOWN_RIGHT 3
#define RESET_SIDE_LEFT 4
#define RESET_SIDE_RIGHT 5
#define RESET_GOALKICK_UP 6
#define RESET_GOALKICK_DOWN 7
#define RESET_GOAL_UP 8
#define RESET_GOAL_DOWN 9
#define PENALTY_UP_X 72
#define PENALTY_UP_Y 303
#define PENALTY_DOWN_X 727
#define PENALTY_DOWN_Y 301
#define GAME_RUN 0
#define GAME_SELECT 1

uint_8 tempvmem[resolution_x*resolution_y];//temp buffer
unsigned char key_pressdown[256];//store keyboard status
int rand_seed;
unsigned char ally_team,oppo_team;
unsigned char ally_score,oppo_score;
unsigned char side_attack;
unsigned char game_status;
float distance[23][23];//the distance between all moving objects, distance[22] stands for football
//define player images for each team
//a little redundant data here because each team has different color
//if i judge it in the drawing process it will be too slow
unsigned char ally_stand_up[1024];
unsigned char ally_stand_down[1024];
unsigned char ally_stand_left[1024];
unsigned char ally_stand_right[1024];
unsigned char ally_run_up[8192];
unsigned char ally_run_down[8192];
unsigned char ally_run_left[8192];
unsigned char ally_run_right[8192];
unsigned char ally_pass_up[8192];
unsigned char ally_pass_down[8192];
unsigned char ally_pass_left[8192];
unsigned char ally_pass_right[8192];
unsigned char ally_lob_up[8192];
unsigned char ally_lob_down[8192];
unsigned char ally_lob_left[8192];
unsigned char ally_lob_right[8192];
unsigned char ally_throw_up[8192];
unsigned char ally_throw_down[8192];
unsigned char ally_throw_left[8192];
unsigned char ally_throw_right[8192];
unsigned char ally_fallrec_up[8192];//fall and recover
unsigned char ally_fallrec_down[8192];
unsigned char ally_fallrec_left[8192];
unsigned char ally_fallrec_right[8192];
unsigned char ally_tackle_up[8192];
unsigned char ally_tackle_down[8192];
unsigned char ally_tackle_left[8192];
unsigned char ally_tackle_right[8192];

unsigned char oppo_stand_up[1024];
unsigned char oppo_stand_down[1024];
unsigned char oppo_stand_left[1024];
unsigned char oppo_stand_right[1024];
unsigned char oppo_run_up[8192];
unsigned char oppo_run_down[8192];
unsigned char oppo_run_left[8192];
unsigned char oppo_run_right[8192];
unsigned char oppo_pass_up[8192];
unsigned char oppo_pass_down[8192];
unsigned char oppo_pass_left[8192];
unsigned char oppo_pass_right[8192];
unsigned char oppo_lob_up[8192];
unsigned char oppo_lob_down[8192];
unsigned char oppo_lob_left[8192];
unsigned char oppo_lob_right[8192];
unsigned char oppo_throw_up[8192];
unsigned char oppo_throw_down[8192];
unsigned char oppo_throw_left[8192];
unsigned char oppo_throw_right[8192];
unsigned char oppo_fallrec_up[8192];//fall and recover
unsigned char oppo_fallrec_down[8192];
unsigned char oppo_fallrec_left[8192];
unsigned char oppo_fallrec_right[8192];
unsigned char oppo_tackle_up[8192];
unsigned char oppo_tackle_down[8192];
unsigned char oppo_tackle_left[8192];
unsigned char oppo_tackle_right[8192];


//math basics
const float pi=3.1415926535898;
const double atanTable[]={	0.785398,0.463648,0.244979,0.124355,0.0624188,0.0312398,0.0156237,0.00781234,0.00390623,0.00195312,0.000976562,0.000488281,0.000244141,0.00012207,6.10352e-005,3.05176e-005,1.52588e-005,7.62939e-006,3.8147e-006,1.90735e-006,9.53674e-007,4.76837e-007,2.38419e-007,1.19209e-007,5.96046e-008,2.98023e-008,1.49012e-008,7.45058e-009,3.72529e-009,1.86265e-009,9.31323e-010,4.65661e-010,2.32831e-010,1.16415e-010,5.82077e-011,2.91038e-011,1.45519e-011,7.27596e-012,3.63798e-012,1.81899e-012,9.09495e-013,4.54747e-013,2.27374e-013,1.13687e-013,5.68434e-014,2.84217e-014,1.42109e-014,7.10543e-015,3.55271e-015,1.77636e-015,8.88178e-016,4.44089e-016,2.22045e-016
};
const float sin_table[]={0,0.0174524,0.0348995,0.052336,0.0697565,0.0871557,0.104528,0.121869,0.139173,0.156434,0.173648,0.190809,0.207912,0.224951,0.241922,0.258819,0.275637,0.292372,0.309017,0.325568,0.34202,0.358368,0.374607,0.390731,0.406737,0.422618,0.438371,0.45399,0.469472,0.48481,0.5,0.515038,0.529919,0.544639,0.559193,0.573576,0.587785,0.601815,0.615661,0.62932,0.642788,0.656059,0.669131,0.681998,0.694658,0.707107,0.71934,0.731354,0.743145,0.75471,0.766044,0.777146,0.788011,0.798636,0.809017,0.819152,0.829038,0.838671,0.848048,0.857167,0.866025,0.87462,0.882948,0.891007,0.898794,0.906308,0.913545,0.920505,0.927184,0.93358,0.939693,0.945519,0.951057,0.956305,0.961262,0.965926,0.970296,0.97437,0.978148,0.981627,0.984808,0.987688,0.990268,0.992546,0.994522,0.996195,0.997564,0.99863,0.999391,0.999848,1,0.999848,0.999391,0.99863,0.997564,0.996195,0.994522,0.992546,0.990268,0.987688,0.984808,0.981627,0.978148,0.97437,0.970296,0.965926,0.961262,0.956305,0.951057,0.945519,0.939693,0.93358,0.927184,0.920505,0.913545,0.906308,0.898794,0.891007,0.882948,0.87462,0.866025,0.857167,0.848048,0.838671,0.829038,0.819152,0.809017,0.798636,0.788011,0.777146,0.766044,0.75471,0.743145,0.731354,0.71934,0.707107,0.694658,0.681998,0.669131,0.656059,0.642788,0.62932,0.615661,0.601815,0.587785,0.573576,0.559193,0.544639,0.529919,0.515038,0.5,0.48481,0.469472,0.45399,0.438371,0.422618,0.406737,0.390731,0.374607,0.358368,0.34202,0.325568,0.309017,0.292372,0.275637,0.258819,0.241922,0.224951,0.207912,0.190809,0.173648,0.156434,0.139173,0.121869,0.104528,0.0871557,0.0697565,0.052336,0.0348995,0.0174524,-6.98296e-015,-0.0174524,-0.0348995,-0.052336,-0.0697565,-0.0871557,-0.104528,-0.121869,-0.139173,-0.156434,-0.173648,-0.190809,-0.207912,-0.224951,-0.241922,-0.258819,-0.275637,-0.292372,-0.309017,-0.325568,-0.34202,-0.358368,-0.374607,-0.390731,-0.406737,-0.422618,-0.438371,-0.45399,-0.469472,-0.48481,-0.5,-0.515038,-0.529919,-0.544639,-0.559193,-0.573576,-0.587785,-0.601815,-0.615661,-0.62932,-0.642788,-0.656059,-0.669131,-0.681998,-0.694658,-0.707107,-0.71934,-0.731354,-0.743145,-0.75471,-0.766044,-0.777146,-0.788011,-0.798636,-0.809017,-0.819152,-0.829038,-0.838671,-0.848048,-0.857167,-0.866025,-0.87462,-0.882948,-0.891007,-0.898794,-0.906308,-0.913545,-0.920505,-0.927184,-0.93358,-0.939693,-0.945519,-0.951057,-0.956305,-0.961262,-0.965926,-0.970296,-0.97437,-0.978148,-0.981627,-0.984808,-0.987688,-0.990268,-0.992546,-0.994522,-0.996195,-0.997564,-0.99863,-0.999391,-0.999848,-1,-0.999848,-0.999391,-0.99863,-0.997564,-0.996195,-0.994522,-0.992546,-0.990268,-0.987688,-0.984808,-0.981627,-0.978148,-0.97437,-0.970296,-0.965926,-0.961262,-0.956305,-0.951057,-0.945519,-0.939693,-0.93358,-0.927184,-0.920505,-0.913545,-0.906308,-0.898794,-0.891007,-0.882948,-0.87462,-0.866025,-0.857167,-0.848048,-0.838671,-0.829038,-0.819152,-0.809017,-0.798636,-0.788011,-0.777146,-0.766044,-0.75471,-0.743145,-0.731354,-0.71934,-0.707107,-0.694658,-0.681998,-0.669131,-0.656059,-0.642788,-0.62932,-0.615661,-0.601815,-0.587785,-0.573576,-0.559193,-0.544639,-0.529919,-0.515038,-0.5,-0.48481,-0.469472,-0.45399,-0.438371,-0.422618,-0.406737,-0.390731,-0.374607,-0.358368,-0.34202,-0.325568,-0.309017,-0.292372,-0.275637,-0.258819,-0.241922,-0.224951,-0.207912,-0.190809,-0.173648,-0.156434,-0.139173,-0.121869,-0.104528,-0.0871557,-0.0697565,-0.052336,-0.0348995,-0.0174524};
const float tan_table[]={0,0.0174551,0.0349208,0.0524078,0.0699268,0.0874887,0.105104,0.122785,0.140541,0.158384,0.176327,0.19438,0.212557,0.230868,0.249328,0.267949,0.286745,0.305731,0.32492,0.344328,0.36397,0.383864,0.404026,0.424475,0.445229,0.466308,0.487733,0.509525,0.531709,0.554309,0.57735,0.600861,0.624869,0.649408,0.674509,0.700208,0.726543,0.753554,0.781286,0.809784,0.8391,0.869287,0.900404,0.932515,0.965689,1,1.03553,1.07237,1.11061,1.15037,1.19175,1.2349,1.27994,1.32704,1.37638,1.42815,1.48256,1.53987,1.60033,1.66428,1.73205,1.80405,1.88073,1.96261,2.0503,2.14451,2.24604,2.35585,2.47509,2.60509,2.74748,2.90421,3.07768,3.27085,3.48741,3.73205,4.01078,4.33148,4.70463,5.14455,5.67128,6.31375,7.11537,8.14435,9.51436,11.4301,14.3007,19.0811,28.6363,57.29,-2.86411e+014,-57.29,-28.6363,-19.0811,-14.3007,-11.4301,-9.51436,-8.14435,-7.11537,-6.31375,-5.67128,-5.14455,-4.70463,-4.33148,-4.01078,-3.73205,-3.48741,-3.27085,-3.07768,-2.90421,-2.74748,-2.60509,-2.47509,-2.35585,-2.24604,-2.14451,-2.0503,-1.96261,-1.88073,-1.80405,-1.73205,-1.66428,-1.60033,-1.53987,-1.48256,-1.42815,-1.37638,-1.32704,-1.27994,-1.2349,-1.19175,-1.15037,-1.11061,-1.07237,-1.03553,-1,-0.965689,-0.932515,-0.900404,-0.869287,-0.8391,-0.809784,-0.781286,-0.753554,-0.726543,-0.700208,-0.674509,-0.649408,-0.624869,-0.600861,-0.57735,-0.554309,-0.531709,-0.509525,-0.487733,-0.466308,-0.445229,-0.424475,-0.404026,-0.383864,-0.36397,-0.344328,-0.32492,-0.305731,-0.286745,-0.267949,-0.249328,-0.230868,-0.212557,-0.19438,-0.176327,-0.158384,-0.140541,-0.122785,-0.105104,-0.0874887,-0.0699268,-0.0524078,-0.0349208,-0.0174551,6.98296e-015,0.0174551,0.0349208,0.0524078,0.0699268,0.0874887,0.105104,0.122785,0.140541,0.158384,0.176327,0.19438,0.212557,0.230868,0.249328,0.267949,0.286745,0.305731,0.32492,0.344328,0.36397,0.383864,0.404026,0.424475,0.445229,0.466308,0.487733,0.509525,0.531709,0.554309,0.57735,0.600861,0.624869,0.649408,0.674509,0.700208,0.726543,0.753554,0.781286,0.809784,0.8391,0.869287,0.900404,0.932515,0.965689,1,1.03553,1.07237,1.11061,1.15037,1.19175,1.2349,1.27994,1.32704,1.37638,1.42815,1.48256,1.53987,1.60033,1.66428,1.73205,1.80405,1.88073,1.96261,2.0503,2.14451,2.24604,2.35585,2.47509,2.60509,2.74748,2.90421,3.07768,3.27085,3.48741,3.73205,4.01078,4.33148,4.70463,5.14455,5.67128,6.31375,7.11537,8.14435,9.51436,11.4301,14.3007,19.0811,28.6363,57.29,-9.54705e+013,-57.29,-28.6363,-19.0811,-14.3007,-11.4301,-9.51436,-8.14435,-7.11537,-6.31375,-5.67128,-5.14455,-4.70463,-4.33148,-4.01078,-3.73205,-3.48741,-3.27085,-3.07768,-2.90421,-2.74748,-2.60509,-2.47509,-2.35585,-2.24604,-2.14451,-2.0503,-1.96261,-1.88073,-1.80405,-1.73205,-1.66428,-1.60033,-1.53987,-1.48256,-1.42815,-1.37638,-1.32704,-1.27994,-1.2349,-1.19175,-1.15037,-1.11061,-1.07237,-1.03553,-1,-0.965689,-0.932515,-0.900404,-0.869287,-0.8391,-0.809784,-0.781286,-0.753554,-0.726543,-0.700208,-0.674509,-0.649408,-0.624869,-0.600861,-0.57735,-0.554309,-0.531709,-0.509525,-0.487733,-0.466308,-0.445229,-0.424475,-0.404026,-0.383864,-0.36397,-0.344328,-0.32492,-0.305731,-0.286745,-0.267949,-0.249328,-0.230868,-0.212557,-0.19438,-0.176327,-0.158384,-0.140541,-0.122785,-0.105104,-0.0874887,-0.0699268,-0.0524078,-0.0349208,-0.0174551};

double atanCordic(double a)
{
    int i;
    double t;
    t = 1;
    
   double x = 1, y = a, z = 0;
    for (i = 0; i < 53; ++i) {
        double x1;
        if ( y < 0) {
            x1 = x - y*t;
            y = y + x*t;
            z = z - atanTable[i];
        }
        else {
            x1 = x + y*t;
            y = y - x*t;
            z = z + atanTable[i];
        }
        x = x1;
        t /= 2;
    }
    return z;
}
inline int abs_int(int number){
	return (number>0)?number:-number;
}
inline float abs_float(float number){
	return (number>0)?number:-number;
}
inline double abs_double(double number){
	return (number>0)?number:-number;
}
float sin_deg(int deg){
	deg=deg % 360;
	deg=(deg<0)? (360+deg) : deg;
	return sin_table[deg];
}
float cos_deg(int deg){
	deg=deg % 360;
	deg=(deg<0)? (360+deg) : deg;
	return (deg<270)?sin_table[deg+90]:sin_table[deg-270];
}
float tan_deg(int deg){
	deg=deg % 360;
	deg=(deg<0)? (360+deg) : deg;
	return tan_table[deg];
}
double atan2(double y, double x) {//return radian in (-pi,pi)
	double coeff_1 = pi / 4.0;
	double coeff_2 = 3.0 * coeff_1;
	double abs_y = abs_double(y);
	double angle;
	if (x >= 0) {
		double r = (x - abs_y) / (x + abs_y);
		angle = coeff_1 - coeff_1 * r;
	} else {
		double r = (x + abs_y) / (abs_y - x);
		angle = coeff_2 - coeff_1 * r;
	}
	return y < 0 ? -angle : angle;
}
int atan2_deg(double y, double x){//return degree in (0,360)
	if(x==0){return y>0?90:270;}
	double atan2_src=atanCordic(y/x)/pi*180;
	if(x<0){
		return 180+atan2_src;
	}else if(y<0){
		return 360+atan2_src;
	}else{
		return atan2_src;
	}
}
float Q_rsqrt( float number )
{//1/sqrt() from quake
	float x2, y;
	const float threehalfs = 1.5F;
	union {
		float f;
		long i;
	}d;
	
	x2  = number * 0.5F;
	y   = number;
	d.f = y;
	d.i   = 0x5f3759df - ( d.i >> 1 ); // what the fuck?
	y   = d.f;
	y   = y * ( threehalfs - ( x2 * y * y ) ); // 1st iteration
	// y   = y * ( threehalfs - ( x2 * y * y ) ); // 2nd iteration, this can be removed
	return y;
}
float my_sqrt(float number){
	return 1/Q_rsqrt(number);
}
//basic function
void my_strcpy(const char * src,char * dst,int length){
	int i=0;
	while(i<length&&src[i]!='\0'){
		dst[i]=src[i];
		i++;
	}
	dst[i]='\0';
}
/*modified*/
inline int
rand() {
	rand_seed = 0x015A4E35 * rand_seed + 1;
	return (rand_seed >> 16) & 0x7FFF;
}
inline int random(int low,int high){
	return rand()%(high-low+1)+low;
}
//structs
struct Point {
	int _x,_y;
};
struct Image {
	const unsigned char * _src;
	int _width,_height;
	int _placex,_placey;
}; 
struct ImageClip {
	struct Image _image;
	int _totalframe;
	int _currentframe;
	int _interval;
	int _timer;
};

struct PlayerAttribute {
	char _name[100];
	unsigned char _position;
	unsigned char _hair_color;
	unsigned char _skin_color;
	float _maxspeed;
	float _acceleration;
	int _dribble;
	int _agility;
	int _aggression;
	int _shoot;
	int _power;
};


struct Team {
	unsigned char _team;
	char _name[100];
	unsigned char _clothes_color;
	unsigned char _pants_color;
	unsigned char _stripe_color;
	unsigned char _sleeve_color;
	struct PlayerAttribute * _player_attributesrc[11];
} teams[6];

#include "data/team.dat"






struct Player {
	//I borrow some concepts from FIFA
	//However you can understand them if you are a soccer fan : )
	
	void * _animation[9][4];//pointer to image and imageclip, 9 status 4 directions
	
	unsigned char _status;
	unsigned char _nextstatus;
	unsigned char _side;
	unsigned char _role;
	unsigned char _task;	
	unsigned char _sprint;//BOOL
	short _threat;
	struct Player * _mark_target;
	
	struct Image _action_still;
	struct Image _arrow;
	struct ImageClip _action_moving;
	
	char _name[100];
	float _x,_y;
	float _basex,_basey;
	float _current_basex,_current_basey;
	int _rotation;
	int _target_rotation;
	float _speed;
	float _maxspeed;
	float _acceleration;
	int _dribble;
	int _agility;
	int _aggression;
	int _shoot;
	int _power;
	unsigned char _action_charging;
	int _charging_power;
	unsigned char _hair_color;
	unsigned char _skin_color;
} players[22];//11 player each side
struct Player * AI_passto;
struct Ball {
	struct Image _action_still;
	struct ImageClip _action_moving;
	
	unsigned char _status;
	
	float _x,_y,_z;//ball has z because it can be kicked high
	float _previous_x;
	float _basex,_basey;
	int _radius;
	int _rotation;
	float _speed;
	float _speedz;
	int _curve;
	struct Player * _holder;
	struct Player * _previous_holder;
} football;

struct Field {
	struct Image _image;
	float _x,_y;
	int _width,_height;
} field;
struct ObjectPointer {
	void * _src;
	unsigned char _type;
} objects[24];
//define pointer to the player that the user is controlling
struct Player * myplayer;

inline unsigned char key_isdown(unsigned char KEY){
	return key_pressdown[KEY];
}

void replace_player_color(unsigned char dst[],const unsigned char src[],int image_size,struct Team * teamsrc){
	int i;
	for(i=0;i<image_size;i++){
		if(src[i]==0x34){//0x34 is default color of clothes
			dst[i]=teamsrc->_clothes_color;
		}else if(src[i]==0x20){//0x20 is default color of pants
			dst[i]=teamsrc->_pants_color;
		}else if(src[i]==0x22){//0x22 is default color of stripe
			dst[i]=teamsrc->_stripe_color;
		}else if(src[i]==0x28){//0x28 is default color of sleeve
			dst[i]=teamsrc->_sleeve_color;
		}else{
			dst[i]=src[i];
		}
	}
}
void generate_field(){
	int i;
	int j;
	//door up
	for(i=300;i<400;i++){
		for(j=54;j>=36;j--){
			acplayground[j*692+i]=0x02;
		}
	}
	for(i=300;i<400;i++){
		for(j=35;j>=33;j--){
			acplayground[j*692+i]=0x0A;
		}
	}
	for(i=0;i<200;i++){
		for(j=86;j>=0;j--){
			int image_x=j;
			int image_y=i;
			int replace_x=54-(86-j);
			int replace_y=249+i;
			if(replace_x<0) continue;
			unsigned char * dstcolorsrc=&acplayground[replace_x*692+replace_y];
			const unsigned char * srccolorsrc=&acdoor_up[image_x*200+image_y];
			if(*srccolorsrc!=0xFF){
				*dstcolorsrc=*srccolorsrc;
			}			
		}
	}
	//door down
	for(i=300;i<400;i++){
		for(j=859;j<=880;j++){
			acplayground[j*692+i]=0x02;
		}
	}
}
void generate_ally_color(struct Team * teamsrc){
	replace_player_color(ally_stand_up,acplayer_stand_up,1024,teamsrc);
	replace_player_color(ally_stand_down,acplayer_stand_down,1024,teamsrc);
	replace_player_color(ally_stand_left,acplayer_stand_left,1024,teamsrc);
	replace_player_color(ally_stand_right,acplayer_stand_right,1024,teamsrc);
	replace_player_color(ally_run_up,acplayer_run_up,8192,teamsrc);
	replace_player_color(ally_run_down,acplayer_run_down,8192,teamsrc);
	replace_player_color(ally_run_left,acplayer_run_left,8192,teamsrc);
	replace_player_color(ally_run_right,acplayer_run_right,8192,teamsrc);
	replace_player_color(ally_pass_up,acplayer_pass_up,8192,teamsrc);
	replace_player_color(ally_pass_down,acplayer_pass_down,8192,teamsrc);
	replace_player_color(ally_pass_left,acplayer_pass_left,8192,teamsrc);
	replace_player_color(ally_pass_right,acplayer_pass_right,8192,teamsrc);
	replace_player_color(ally_lob_up,acplayer_lob_up,8192,teamsrc);
	replace_player_color(ally_lob_down,acplayer_lob_down,8192,teamsrc);
	replace_player_color(ally_lob_left,acplayer_lob_left,8192,teamsrc);
	replace_player_color(ally_lob_right,acplayer_lob_right,8192,teamsrc);
	replace_player_color(ally_throw_up,acplayer_throw_up,8192,teamsrc);
	replace_player_color(ally_throw_down,acplayer_throw_down,8192,teamsrc);
	replace_player_color(ally_throw_left,acplayer_throw_left,8192,teamsrc);
	replace_player_color(ally_throw_right,acplayer_throw_right,8192,teamsrc);
	replace_player_color(ally_fallrec_up,acplayer_fallrec_up,8192,teamsrc);
	replace_player_color(ally_fallrec_down,acplayer_fallrec_down,8192,teamsrc);
	replace_player_color(ally_fallrec_left,acplayer_fallrec_left,8192,teamsrc);
	replace_player_color(ally_fallrec_right,acplayer_fallrec_right,8192,teamsrc);
	replace_player_color(ally_tackle_up,acplayer_tackle_up,8192,teamsrc);
	replace_player_color(ally_tackle_down,acplayer_tackle_down,8192,teamsrc);
	replace_player_color(ally_tackle_left,acplayer_tackle_left,8192,teamsrc);
	replace_player_color(ally_tackle_right,acplayer_tackle_right,8192,teamsrc);
}
void generate_oppo_color(struct Team * teamsrc){
	replace_player_color(oppo_stand_up,acplayer_stand_up,1024,teamsrc);
	replace_player_color(oppo_stand_down,acplayer_stand_down,1024,teamsrc);
	replace_player_color(oppo_stand_left,acplayer_stand_left,1024,teamsrc);
	replace_player_color(oppo_stand_right,acplayer_stand_right,1024,teamsrc);
	replace_player_color(oppo_run_up,acplayer_run_up,8192,teamsrc);
	replace_player_color(oppo_run_down,acplayer_run_down,8192,teamsrc);
	replace_player_color(oppo_run_left,acplayer_run_left,8192,teamsrc);
	replace_player_color(oppo_run_right,acplayer_run_right,8192,teamsrc);
	replace_player_color(oppo_pass_up,acplayer_pass_up,8192,teamsrc);
	replace_player_color(oppo_pass_down,acplayer_pass_down,8192,teamsrc);
	replace_player_color(oppo_pass_left,acplayer_pass_left,8192,teamsrc);
	replace_player_color(oppo_pass_right,acplayer_pass_right,8192,teamsrc);
	replace_player_color(oppo_lob_up,acplayer_lob_up,8192,teamsrc);
	replace_player_color(oppo_lob_down,acplayer_lob_down,8192,teamsrc);
	replace_player_color(oppo_lob_left,acplayer_lob_left,8192,teamsrc);
	replace_player_color(oppo_lob_right,acplayer_lob_right,8192,teamsrc);
	replace_player_color(oppo_throw_up,acplayer_throw_up,8192,teamsrc);
	replace_player_color(oppo_throw_down,acplayer_throw_down,8192,teamsrc);
	replace_player_color(oppo_throw_left,acplayer_throw_left,8192,teamsrc);
	replace_player_color(oppo_throw_right,acplayer_throw_right,8192,teamsrc);
	replace_player_color(oppo_fallrec_up,acplayer_fallrec_up,8192,teamsrc);
	replace_player_color(oppo_fallrec_down,acplayer_fallrec_down,8192,teamsrc);
	replace_player_color(oppo_fallrec_left,acplayer_fallrec_left,8192,teamsrc);
	replace_player_color(oppo_fallrec_right,acplayer_fallrec_right,8192,teamsrc);
	replace_player_color(oppo_tackle_up,acplayer_tackle_up,8192,teamsrc);
	replace_player_color(oppo_tackle_down,acplayer_tackle_down,8192,teamsrc);
	replace_player_color(oppo_tackle_left,acplayer_tackle_left,8192,teamsrc);
	replace_player_color(oppo_tackle_right,acplayer_tackle_right,8192,teamsrc);
}

void generate_player(struct PlayerAttribute * attrsrc,struct Player * playerdst){
	my_strcpy(attrsrc->_name,playerdst->_name,100);
	playerdst->_maxspeed=attrsrc->_maxspeed;
	playerdst->_acceleration=attrsrc->_acceleration;
	playerdst->_dribble=attrsrc->_dribble;
	playerdst->_agility=attrsrc->_agility;
	playerdst->_aggression=attrsrc->_aggression;
	playerdst->_shoot=attrsrc->_shoot;
	playerdst->_power=attrsrc->_power;
	playerdst->_hair_color=attrsrc->_hair_color;
	playerdst->_skin_color=attrsrc->_skin_color;
}
void controll_my_player_action(){
	static unsigned char w_down=FALSE;
	static unsigned char s_down=FALSE;
	static unsigned char a_down=FALSE;
	static unsigned char d_down=FALSE;
	static unsigned char q_down=FALSE;
	static unsigned char e_down=FALSE;
	
	
	w_down=key_isdown(KEY_W);
	s_down=key_isdown(KEY_S);
	a_down=key_isdown(KEY_A);
	d_down=key_isdown(KEY_D);
	q_down=key_isdown(KEY_Q);
	e_down=key_isdown(KEY_E);
	
	if(myplayer->_action_charging!=PLAYER_NONE){
		if(myplayer->_action_charging==PLAYER_PASS){
			if(s_down){
				if(myplayer->_charging_power<100){
					myplayer->_charging_power+=CHARGE_SPEED;
				}
			}else{
				myplayer->_nextstatus=PLAYER_PASS;
				myplayer->_action_charging=PLAYER_NONE;
			}
		}else if(myplayer->_action_charging==PLAYER_LOB){
			if(a_down){
				if(myplayer->_charging_power<100){
					myplayer->_charging_power+=CHARGE_SPEED;
				}
			}else{
				myplayer->_nextstatus=PLAYER_LOB;
				myplayer->_action_charging=PLAYER_NONE;
			}
		}else if(myplayer->_action_charging==PLAYER_THROW){
			if(s_down){
				if(myplayer->_charging_power<100){
					myplayer->_charging_power+=CHARGE_SPEED;
				}
			}else{
				myplayer->_nextstatus=PLAYER_THROW;
				myplayer->_action_charging=PLAYER_NONE;
			}
		}else if(myplayer->_action_charging==PLAYER_SHOOT){
			if(d_down){
				if(myplayer->_charging_power<100){
					myplayer->_charging_power+=CHARGE_SPEED;
				}
			}else{
				myplayer->_nextstatus=PLAYER_SHOOT;
				myplayer->_action_charging=PLAYER_NONE;
			}
		}else if(myplayer->_action_charging==PLAYER_THROUGHPASS){
			if(w_down){
				if(myplayer->_charging_power<100){
					myplayer->_charging_power+=CHARGE_SPEED;
				}
			}else{
				myplayer->_nextstatus=PLAYER_THROUGHPASS;
				myplayer->_action_charging=PLAYER_NONE;
			}
		}
		return;
	}
	
	myplayer->_sprint=e_down;
	
	if(q_down){
		//switch player
		int closest_ally_player=0;
		int i;
		for(i=0;i<11;i++){
			if(distance[22][i]<distance[22][closest_ally_player]){
				closest_ally_player=i;
			}
		}
		myplayer=&players[closest_ally_player];
	}
	if(d_down){
		if(myplayer->_status<=PLAYER_RUN){//careful
			if(myplayer->_side==side_attack&&football._holder==myplayer){
				myplayer->_action_charging=PLAYER_SHOOT;
				myplayer->_charging_power=0;
			}
		}
	}else if(s_down){
		if(myplayer->_status<=PLAYER_RUN){
			if(myplayer->_side==side_attack&&football._holder==myplayer){
				myplayer->_action_charging=PLAYER_PASS;
				myplayer->_charging_power=0;
			}else if(myplayer->_side==side_attack){
				//auto defend
			}
		}
	}else if(w_down){
		if(myplayer->_status<=PLAYER_RUN){
			if(myplayer->_side==side_attack&&football._holder==myplayer){
				myplayer->_action_charging=PLAYER_THROUGHPASS;
				myplayer->_charging_power=0;
			}
		}
	}else if(a_down){
		if(myplayer->_status<=PLAYER_RUN){
			if(myplayer->_side==side_attack&&football._holder==myplayer){
				myplayer->_action_charging=PLAYER_LOB;
				myplayer->_charging_power=0;
			}else if(myplayer->_side!=side_attack){
				myplayer->_nextstatus=PLAYER_TACKLE;
			}
		}
	}
}
void controll_my_player_direction(){//status!!!
	static unsigned char up_down=FALSE;
	static unsigned char down_down=FALSE;
	static unsigned char left_down=FALSE;
	static unsigned char right_down=FALSE;
	if(myplayer->_nextstatus!=PLAYER_STAND){return;}
	myplayer->_nextstatus=PLAYER_RUN;
	up_down=key_isdown(KEY_UP);
	down_down=key_isdown(KEY_DOWN);
	left_down=key_isdown(KEY_LEFT);
	right_down=key_isdown(KEY_RIGHT);
	if(up_down&&down_down){
		myplayer->_nextstatus=PLAYER_STAND;
		return;
	}
	if(left_down&&right_down){
		myplayer->_nextstatus=PLAYER_STAND;
		return;
	}
	if(up_down){
		if(left_down){
			myplayer->_target_rotation=315;
		}else if(right_down){
			myplayer->_target_rotation=45;
		}else{
			myplayer->_target_rotation=0;
		}
	}else if(down_down){
		if(left_down){
			myplayer->_target_rotation=225;
		}else if(right_down){
			myplayer->_target_rotation=135;
		}else{
			myplayer->_target_rotation=180;
		}
	}else if(left_down){
		myplayer->_target_rotation=270;
	}else if(right_down){
		myplayer->_target_rotation=90;
	}else{
		myplayer->_nextstatus=PLAYER_STAND;
	}
}
inline float calc_distance(int x1,int y1,int x2,int y2){
	int disx=x1-x2;
	int disy=y1-y2;
	return my_sqrt(disx*disx+disy*disy);
}
void get_current_base(struct Player * playersrc,unsigned char base_type){
	if(playersrc->_role==ROLE_GK){
		playersrc->_current_basey=football._y;
		if(playersrc->_current_basey<DOOR_UP_LEFT){
			playersrc->_current_basey=DOOR_UP_LEFT;
		}else if(playersrc->_current_basey>DOOR_UP_RIGHT){
			playersrc->_current_basey=DOOR_UP_RIGHT;
		}
		playersrc->_current_basex=playersrc->_basex;
		return;
	}
	if(playersrc->_side==side_attack){
	//for attackers
		if((playersrc->_side==SIDE_ALLY&&football._x>football._basex)||((playersrc->_side==SIDE_OPPO&&football._x<football._basex))){//the ball is not at the other side of the field
			playersrc->_current_basex=playersrc->_basex;
		}else{
			playersrc->_current_basex=playersrc->_basex+football._holder->_x-football._holder->_basex;	
		}
		if(base_type==BASE_FORWARD){
			playersrc->_current_basex+=(playersrc->_side==SIDE_ALLY)?-100:100;
		}else if(base_type==BASE_PUSH){
			playersrc->_current_basex+=(playersrc->_side==SIDE_ALLY)?-random(100,350):random(100,350);
		}
		if(playersrc->_side==SIDE_ALLY&&playersrc->_current_basex<playersrc->_basex-350){
			playersrc->_current_basex=playersrc->_basex-350;
		}else if(playersrc->_side==SIDE_OPPO&&playersrc->_current_basex>playersrc->_basex+350){
			playersrc->_current_basex=playersrc->_basex+350;
		}
		playersrc->_current_basey=playersrc->_basey+(football._y-playersrc->_basey)/4;
	}else{
	//for defenders
		int playerpos=0,defendpos;
		int i;
		for(i=0;i<22;i++){
			if(&players[i]==playersrc){
				playerpos=i;
				break;
			}
		}
		if(playerpos>=11){
			defendpos=playerpos-11;
		}else{
			defendpos=playerpos+11;
		}
		if(distance[playerpos][defendpos]<MARK_RANGE_SQUARE||(playersrc->_side==SIDE_ALLY&&players[defendpos]._x>playersrc->_basex)||(playersrc->_side==SIDE_OPPO&&players[defendpos]._x<playersrc->_basex)){
			playersrc->_current_basex=players[defendpos]._x+((playersrc->_side==SIDE_ALLY)?20:-20);
			playersrc->_current_basey=players[defendpos]._y;
		}else{
			playersrc->_current_basex=playersrc->_basex;
			playersrc->_current_basey=playersrc->_basey;
		}
	}
}
void assign_task_mark(struct Player * playersrc,struct Player * mark_target){
	playersrc->_mark_target=mark_target;
	playersrc->_task=TASK_MARK;
}
void assign_task_adjust(struct Player * playersrc){
	playersrc->_task=TASK_ADJUST;
}
void assign_task_forwardrun(struct Player * playersrc){
	get_current_base(playersrc,BASE_FORWARD);
	playersrc->_task=TASK_FORWARDRUN;
}
void assign_task_pushline(struct Player * playersrc){
	get_current_base(playersrc,BASE_PUSH);
	playersrc->_task=TASK_PUSHLINE;
}
void assign_task_getball(struct Player * playersrc){
	playersrc->_task=TASK_GETBALL;
}
void assign_task_tackle(struct Player * playersrc){
	playersrc->_task=TASK_TACKLE;
	playersrc->_nextstatus=PLAYER_TACKLE;
}
void assign_task_pass(struct Player * playersrc){
	playersrc->_task=TASK_PASS;
	
	int attackstart=(myplayer->_side==side_attack)?0:11;
	int max_threat_pos;
	int playerpos;
	int i;
	for(playerpos=attackstart;playerpos<attackstart+11;playerpos++){
		if(playersrc==&players[playerpos])break;
	}	
	if(playerpos==attackstart){
		max_threat_pos=attackstart+1;
	}else{
		max_threat_pos=attackstart;
	}
	for(i=attackstart;i<attackstart+11;i++){
		if(i!=playerpos&&players[i]._threat>players[max_threat_pos]._threat){
			max_threat_pos=i;
		}
	}
	
	playersrc->_rotation=atan2_deg(players[max_threat_pos]._y-playersrc->_y,playersrc->_x-players[max_threat_pos]._x);
	float real_distance=my_sqrt(distance[playerpos][max_threat_pos]);
	if(real_distance>LONGPASS_TRIGGER){
		playersrc->_charging_power=my_sqrt(2*AIR_FRICTION*real_distance)*16;
		playersrc->_nextstatus=PLAYER_LOB;
	}else{
		playersrc->_charging_power=my_sqrt(2*GROUND_FRICTION*real_distance)*18;
		playersrc->_nextstatus=PLAYER_PASS;
	}	
	if(playersrc->_charging_power>100){
		playersrc->_charging_power=100;
	}
	AI_passto=&players[max_threat_pos];
	assign_task_getball(AI_passto);
	
}
unsigned char assign_task_shoot(struct Player * playersrc){//should check more conditions
	int shoot_decide_lucky=random(0,100);
	if(shoot_decide_lucky>playersrc->_shoot){
		return FALSE;
	}
	int door_x,door_left,door_right;
	
	if(playersrc->_side==SIDE_ALLY){
		door_x=DOOR_UP;
		door_left=DOOR_UP_LEFT;
		door_right=DOOR_UP_RIGHT;
	}else{
		door_x=DOOR_DOWN;
		door_left=DOOR_DOWN_LEFT;
		door_right=DOOR_DOWN_RIGHT;
	}
	float desx,desy;
	desx=playersrc->_x-door_x;
	desy=(door_left+door_right)/2-playersrc->_y;
	float distance_to_door=calc_distance(playersrc->_x,playersrc->_y,door_x,(door_left+door_right)/2);
	if(distance_to_door>SHOOT_RANGE) return FALSE;
	int shoot_lucky=random(0,playersrc->_shoot);
	int target_y;
	if(shoot_lucky<15){// out left
		target_y=random(door_left-50,door_left-5);
	}else if(shoot_lucky<30){// out right
		target_y=random(door_right+5,door_right+50);
	}else if(shoot_lucky<50){// in the center
		target_y=random((door_left+door_right)/2-15,(door_left+door_right)/2+15);
	}else{// perfect shoot
		int perfect_lucky=random(0,1);
		if(perfect_lucky==0){// perfect left
			target_y=random(door_left+5,door_left+10);
		}else{// perfect right
			target_y=random(door_right-10,door_right-5);
		}
	}
	desx=playersrc->_x-door_x;
	desy=target_y-playersrc->_y;
	float real_distance=my_sqrt(desx*desx+desy*desy);
	playersrc->_rotation=atan2_deg(desy,desx);
	playersrc->_charging_power=real_distance*0.6;
	if(playersrc->_charging_power>100){
		playersrc->_charging_power=100;
	}
	playersrc->_nextstatus=PLAYER_SHOOT;
	playersrc->_task=TASK_SHOOT;
	return TRUE;
}
unsigned char check_offside(struct Player * playersrc){
	int i;
	if(playersrc->_side==SIDE_ALLY){
		for(i=12;i<22;i++){
			if(playersrc->_x<players[i]._x) return TRUE;
		}
	}else{
		for(i=1;i<11;i++){
			if(playersrc->_x>players[i]._x) return TRUE;
		}
	}
	return FALSE;
}
void controll_AI_players(){
	//static int ai_exec_timer = 0;//set interval to reduce calculation
	int i;
	int j;
	int attackstart;
	int defendstart;
	if(myplayer->_side==side_attack){//determine attackers and defenders
		attackstart=0;
		defendstart=11;
	}else{
		attackstart=11;
		defendstart=0;
	}
	//calculate threats
	for(i=attackstart;i<attackstart+11;i++){
		players[i]._threat=(players[i]._dribble+players[i]._shoot)/2-((players[i]._side==SIDE_ALLY)?(players[i]._x-DOOR_UP):(DOOR_DOWN-players[i]._x))/10+((football._holder==&players[i])?-40:-60);
	}
	//assign task
	//common
	if(football._holder==NULL){
		int ally_ball_catcher=0;
		int oppo_ball_catcher=11;
		for(i=0;i<22;i++){
			if(players[i]._task==TASK_GETBALL&&AI_passto!=&players[i]){//prevent all the players to get the ball at the same time
				players[i]._task=TASK_NONE;
			}
		}
		for(i=1;i<11;i++){//goal keeper wont go getball
			if(&players[i]==myplayer)continue;
			if(distance[22][i]<distance[22][ally_ball_catcher]){
				ally_ball_catcher=i;
			}
		}
		for(i=12;i<22;i++){
			if(&players[i]==myplayer)continue;
			if(distance[22][i]<distance[22][oppo_ball_catcher]){
				oppo_ball_catcher=i;
			}
		}
		assign_task_getball(&players[ally_ball_catcher]);
		assign_task_getball(&players[oppo_ball_catcher]);
	}
	//attackers
	for(i=attackstart;i<attackstart+11;i++){
		if(&players[i]==myplayer) continue;//don't controll user player
		if(players[i]._task==TASK_NONE){//no task now, assign task
			int action_lucky=random(0,100);
			if(football._holder==&players[i]){//has ball				
				if(players[i]._role==ROLE_GK){
					//kick out the ball with big power
					if(players[i]._side==SIDE_ALLY){
						players[i]._rotation=0;
					}else{
						players[i]._rotation=180;
					}
					players[i]._charging_power=90;
					players[i]._nextstatus=PLAYER_LOB;
					
				}else if(players[i]._role==ROLE_RB||players[i]._role==ROLE_LB){
					// 1/3 pass 2/3 forward
					if(action_lucky<66){//bigger possibility go first
						assign_task_forwardrun(&players[i]);
					}else{
						assign_task_pass(&players[i]);
					}				
				}else if(players[i]._role==ROLE_CB){
					// 3/4 pass 1/4 forward 
					if(action_lucky<75){
						assign_task_pass(&players[i]);
					}else{
						assign_task_forwardrun(&players[i]);
					}
				}else if(players[i]._role==ROLE_CDM){
					// 2/4 pass 2/4 forward
					if(action_lucky<50){
						assign_task_forwardrun(&players[i]);
					}else{
						assign_task_pass(&players[i]);
					}
				}else if(players[i]._role==ROLE_LM||players[i]._role==ROLE_RM){
					// 1/4 pass 3/4 pushline
					if(action_lucky<75){
						assign_task_pushline(&players[i]);
					}else{
						assign_task_pass(&players[i]);
					}
				}else if(players[i]._role==ROLE_CAM){
					// check shoot first, then 2/4 pass 2/4 pushline
					if(assign_task_shoot(&players[i])==FALSE){
						if(action_lucky<50){
							assign_task_pushline(&players[i]);
						}else{
							assign_task_pass(&players[i]);
						}
					}
				}else if(players[i]._role==ROLE_ST||players[i]._role==ROLE_CF){
					// check shoot first, then 3/4 pass 1/4 pushline
					if(assign_task_shoot(&players[i])==FALSE){
						if(action_lucky<75){
							assign_task_pass(&players[i]);
						}else{
							assign_task_pushline(&players[i]);
						}
					}
				}	
			}else{//without ball
				if(players[i]._role==ROLE_GK){
					// 1/6 adjust 5/6 none
					if(action_lucky<83){
						assign_task_adjust(&players[i]);
					}
				}else if(players[i]._role==ROLE_RB||players[i]._role==ROLE_LB){
					// 1/6 forward 2/6 none 3/6 adjust
					if(action_lucky<50){
						assign_task_adjust(&players[i]);
					}else if(action_lucky<67){
						assign_task_forwardrun(&players[i]);
					}
				}else if(players[i]._role==ROLE_CB){
					// 1/16 forward 4/8 none 3/8 adjust
					if(action_lucky<37){
						assign_task_adjust(&players[i]);
					}else if(action_lucky<43){
						assign_task_forwardrun(&players[i]);
					}
				}else if(players[i]._role==ROLE_CDM){
					// 1/8 forward 4/8 none 3/8 adjust
					if(action_lucky<37){
						assign_task_adjust(&players[i]);
					}else if(action_lucky<50){
						assign_task_forwardrun(&players[i]);
					}
				}else if(players[i]._role==ROLE_LM||players[i]._role==ROLE_RM){
					//check if offside backoff, then 1/6 forward 2/6 none 3/6 adjust
					if(action_lucky<50||check_offside(&players[i])==TRUE){
						assign_task_adjust(&players[i]);
					}else if(action_lucky<66){
						assign_task_forwardrun(&players[i]);
					}
				}else if(players[i]._role==ROLE_CAM){
					//check if offside backoff, then 1/4 forward 1/4 none 2/4 adjust
					if(action_lucky<50||check_offside(&players[i])==TRUE){
						assign_task_adjust(&players[i]);
					}else if(action_lucky<75){
						assign_task_forwardrun(&players[i]);
					}
				}else if(players[i]._role==ROLE_ST||players[i]._role==ROLE_CF){
					//check if offside backoff, then 1/8 forward 4/8 none 3/8 adjust
					if(action_lucky<37||check_offside(&players[i])==TRUE){
						assign_task_adjust(&players[i]);
					}else if(action_lucky<50){
						assign_task_forwardrun(&players[i]);
					}
				}
	
			}
			
		}
	}
	//defenders
	//first assign markers
	for(i=defendstart;i<defendstart+11;i++){
		if(players[i]._mark_target!=NULL){
			players[i]._mark_target->_threat-=players[i]._aggression/3;
		}
	}
	for(i=attackstart;i<attackstart+11;i++){
		while(players[i]._threat>THREAT_TRIGGER){
			for(j=defendstart;j<defendstart+11;j++){
				float distance_to_base=calc_distance(players[j]._basex,players[j]._basey,players[i]._x,players[i]._y);
				if(distance_to_base<MARK_RANGE&&players[j]._role!=ROLE_GK&&players[j]._task!=TASK_MARK&&players[j]._task!=TASK_TACKLE&&players[j]._task!=TASK_GETBALL){
					assign_task_mark(&players[j],&players[i]);
					players[i]._threat-=players[j]._aggression/3;
					break;
				}
			}
			if(j==defendstart+11) break;
		}
	}
	//then assign other tasks
	for(i=defendstart;i<defendstart+11;i++){
		if(&players[i]==myplayer) continue;//don't controll user player
		if(players[i]._task==TASK_NONE){//no task now, assign task
			//int action_lucky=random(0,100);
			if(players[i]._role==ROLE_GK){
				//adjust position
				assign_task_adjust(&players[i]);
				
			}else if(players[i]._role==ROLE_RB||players[i]._role==ROLE_LB){

				//if(action_lucky<33){
					assign_task_adjust(&players[i]);
				//}else if(action_lucky<66){
					//assign_task_forwardrun(&players[i]);
				//}else{
				//}
			}else if(players[i]._role==ROLE_CB){
				assign_task_adjust(&players[i]);
			}else if(players[i]._role==ROLE_CDM){
				assign_task_adjust(&players[i]);
			}else if(players[i]._role==ROLE_LM||players[i]._role==ROLE_RM){
				assign_task_adjust(&players[i]);
			}else if(players[i]._role==ROLE_CAM){
				assign_task_adjust(&players[i]);					
			}else if(players[i]._role==ROLE_ST||players[i]._role==ROLE_CF){
				assign_task_adjust(&players[i]);
			}
		}else if(players[i]._task==TASK_MARK){
			if(distance[22][i]<TACKLE_RANGE_SQUARE&&players[i]._mark_target->_threat>TACKLE_TRIGGER){
				assign_task_tackle(&players[i]);
			}
		}
	}
	//execute task and determine if the task ends
	for(i=0;i<22;i++){
		if(&players[i]==myplayer) continue;
		if(players[i]._task==TASK_NONE){
			continue;
		}else if(players[i]._task==TASK_MARK){//order?
			int k,markpos=attackstart;
			if(players[i]._side==side_attack){
				players[i]._mark_target=NULL;
				players[i]._task=TASK_NONE;
				continue;
			}
			for(k=attackstart;k<attackstart+11;k++){
				if(&players[k]==players[i]._mark_target){
					markpos=k;
					break;
				}
			}
			get_current_base(&players[i],BASE_NORMAL);
			float distance_to_base=calc_distance(players[markpos]._x,players[markpos]._y,players[i]._current_basex,players[i]._current_basey);
			if(distance_to_base>MARK_RANGE){
				players[i]._mark_target=NULL;
				players[i]._task=TASK_NONE;
				continue;
			}
			players[i]._sprint=TRUE;
			players[i]._target_rotation=atan2_deg(players[i]._mark_target->_y-players[i]._y,players[i]._x-players[i]._mark_target->_x);
			players[i]._nextstatus=PLAYER_RUN;
		}else if(players[i]._task==TASK_ADJUST){
			get_current_base(&players[i],BASE_NORMAL);
			if(abs_float(players[i]._current_basex-players[i]._x)<ARRIVE_RANGEX && abs_float(players[i]._current_basey-players[i]._y)<ARRIVE_RANGEY){
				players[i]._task=TASK_NONE;
				continue;
			}
			float distance_to_target=calc_distance(players[i]._x,players[i]._y,players[i]._current_basex,players[i]._current_basey);
			if(distance_to_target>RUN_TRIGGER){
				players[i]._sprint=TRUE;
			}else{
				players[i]._sprint=FALSE;
			}
			players[i]._target_rotation=atan2_deg(players[i]._current_basey-players[i]._y,players[i]._x-players[i]._current_basex);
			players[i]._nextstatus=PLAYER_RUN;
		}else if(players[i]._task==TASK_FORWARDRUN||players[i]._task==TASK_PUSHLINE){
			if(abs_float(players[i]._current_basex-players[i]._x)<ARRIVE_RANGEX && abs_float(players[i]._current_basey-players[i]._y)<ARRIVE_RANGEY){
				players[i]._task=TASK_NONE;
				continue;
			}
			players[i]._sprint=TRUE;
			players[i]._target_rotation=atan2_deg(players[i]._current_basey-players[i]._y,players[i]._x-players[i]._current_basex);
			players[i]._nextstatus=PLAYER_RUN;
		}else if(players[i]._task==TASK_GETBALL){
			if(football._holder!=NULL){
				players[i]._task=TASK_NONE;
				continue;
			}
			float distance_to_target=calc_distance(players[i]._x,players[i]._y,football._x,football._y);
			if(distance_to_target>RUN_TRIGGER){
				players[i]._sprint=TRUE;
			}else{
				players[i]._sprint=FALSE;
			}
			players[i]._target_rotation=atan2_deg(football._y-players[i]._y,players[i]._x-football._x);
			players[i]._nextstatus=PLAYER_RUN;
		}else if(players[i]._task==TASK_TACKLE){
			if(players[i]._status==PLAYER_TACKLE&&(players[i]._action_moving._currentframe==7)&&(players[i]._action_moving._timer==1)){//7 is totalframe-1,1 is interval-1
				players[i]._task=TASK_NONE;
				continue;
			}
			
		}else if(players[i]._task==TASK_PASS){
			if(players[i]._status==PLAYER_PASS&&(players[i]._action_moving._currentframe==7)&&(players[i]._action_moving._timer==1)){//7 is totalframe-1,1 is interval-1
				players[i]._task=TASK_NONE;
				continue;
			}
			
		}else if(players[i]._task==TASK_SHOOT){
			if(players[i]._status==PLAYER_SHOOT&&(players[i]._action_moving._currentframe==7)&&(players[i]._action_moving._timer==1)){//7 is totalframe-1,1 is interval-1
				players[i]._task=TASK_NONE;
				continue;
			}
		}
	}
}
void reset_stage(unsigned char reset_type){
	int i;
	int ball_picker=0;//always set CDM to pick the ball
	int attackstart=0,defendstart=0;
	
	football._z=0;
	football._speed=0;
	football._speedz=0;
	if(reset_type==RESET_CORNER_UP_LEFT){
		football._x=6;
		football._y=6;
		ball_picker=5;
		myplayer=&players[ball_picker];
		players[ball_picker]._x=0;
		players[ball_picker]._y=0;
		players[ball_picker]._rotation=100;
		assign_task_pass(&players[ball_picker]);
		attackstart=0;
		defendstart=11;
	}else if(reset_type==RESET_CORNER_UP_RIGHT){
		football._x=6;
		football._y=596;
		ball_picker=5;
		myplayer=&players[ball_picker];
		players[ball_picker]._x=0;
		players[ball_picker]._y=600;
		players[ball_picker]._rotation=260;
		assign_task_pass(&players[ball_picker]);
		attackstart=0;
		defendstart=11;
	}else if(reset_type==RESET_CORNER_DOWN_LEFT){
		football._x=796;
		football._y=6;
		ball_picker=16;
		players[ball_picker]._x=800;
		players[ball_picker]._y=0;
		players[ball_picker]._rotation=80;
		assign_task_pass(&players[ball_picker]);
		attackstart=11;
		defendstart=0;
	}else if(reset_type==RESET_CORNER_DOWN_RIGHT){
		football._x=796;
		football._y=596;
		ball_picker=16;
		players[ball_picker]._x=800;
		players[ball_picker]._y=600;
		players[ball_picker]._rotation=350;
		assign_task_pass(&players[ball_picker]);
		attackstart=11;
		defendstart=0;
	}else if(reset_type==RESET_GOALKICK_UP){
		football._x=PENALTY_UP_X;
		football._y=PENALTY_UP_Y;
		ball_picker=11;
		players[ball_picker]._x=68;
		players[ball_picker]._y=303;
		players[ball_picker]._rotation=180;
		assign_task_pass(&players[ball_picker]);
		attackstart=11;
		defendstart=0;
	}else if(reset_type==RESET_GOALKICK_DOWN){
		football._x=PENALTY_DOWN_X;
		football._y=PENALTY_DOWN_Y;
		ball_picker=0;
		players[ball_picker]._x=731;
		players[ball_picker]._y=301;
		players[ball_picker]._rotation=0;
		assign_task_pass(&players[ball_picker]);
		attackstart=0;
		defendstart=11;
	}else if(reset_type==RESET_SIDE_LEFT){
		football._x=football._previous_x;
		football._y=1;
		if(football._previous_holder->_side==SIDE_ALLY){
			ball_picker=16;
			attackstart=11;
			defendstart=0;
		}else{
			ball_picker=5;
			attackstart=0;
			defendstart=11;
		}
		players[ball_picker]._x=football._x;
		players[ball_picker]._y=0;
		players[ball_picker]._rotation=90;
		assign_task_pass(&players[ball_picker]);
	}else if(reset_type==RESET_SIDE_RIGHT){
		football._x=football._previous_x;
		football._y=599;
		if(football._previous_holder->_side==SIDE_ALLY){
			ball_picker=16;
			attackstart=11;
			defendstart=0;
		}else{
			ball_picker=5;
			attackstart=0;
			defendstart=11;
		}
		players[ball_picker]._x=football._x;
		players[ball_picker]._y=600;
		players[ball_picker]._rotation=270;
		assign_task_pass(&players[ball_picker]);
	}else if(reset_type==RESET_GOAL_UP||reset_type==RESET_GOAL_DOWN){
		football._x=football._basex;
		football._y=football._basey;
		if(reset_type==RESET_GOAL_UP){
			ball_picker=21;
			attackstart=11;
			defendstart=0;
		}else{			
			ball_picker=10;
			myplayer=&players[ball_picker];
			attackstart=0;
			defendstart=11;
		}
		players[ball_picker]._x=football._x;
		players[ball_picker]._y=football._y-8;
		players[ball_picker]._rotation=90;
		players[ball_picker-1]._x=football._x;
		players[ball_picker-1]._y=football._y+8;
		players[ball_picker-1]._rotation=270;
		assign_task_pass(&players[ball_picker]);
	}
		
	side_attack=players[ball_picker]._side;
	football._holder=&players[ball_picker];
	
	for(i=attackstart;i<attackstart+11;i++){
		if(i==ball_picker)continue;
		if(reset_type>=RESET_CORNER_UP_LEFT&&reset_type<=RESET_CORNER_DOWN_RIGHT){
			get_current_base(&players[i],BASE_PUSH);
		}else if(reset_type==RESET_SIDE_LEFT||reset_type==RESET_SIDE_RIGHT){
			get_current_base(&players[i],BASE_NORMAL);
		}
		if(reset_type==RESET_GOAL_UP||reset_type==RESET_GOAL_DOWN||reset_type==RESET_GOALKICK_UP||reset_type==RESET_GOALKICK_DOWN){
			players[i]._x=players[i]._basex;
			players[i]._y=players[i]._basey;
		}else{
			players[i]._x=players[i]._current_basex;
			players[i]._y=players[i]._current_basey;
		}
		
	}
	for(i=defendstart;i<defendstart+11;i++){
		get_current_base(&players[i],BASE_NORMAL);
		if(reset_type==RESET_GOAL_UP||reset_type==RESET_GOAL_DOWN||reset_type==RESET_GOALKICK_UP||reset_type==RESET_GOALKICK_DOWN){
			players[i]._x=players[i]._basex;
			players[i]._y=players[i]._basey;
		}else{
			players[i]._x=players[i]._current_basex;
			players[i]._y=players[i]._current_basey;
		}
	}
	
	for(i=0;i<22;i++){
		//if(i!=ball_picker){players[i]._task=TASK_NONE;}
		//players[i]._status=PLAYER_STAND;
		//players[i]._nextstatus=PLAYER_STAND;
		players[i]._speed=0;
		players[i]._rotation=atan2_deg(football._y-players[i]._y,players[i]._x-football._x);
		
	}
}
void arrange_players(){
}
void controll_ball(){
	int i;
	if(football._status==BALL_NORMAL){
		if(football._holder!=NULL){
			//first check if he can still hold the ball
			int startpos=0;
			if(football._holder->_side==SIDE_ALLY){
				startpos=11;
			}else{
				startpos=0;
			}
			for(i=startpos;i<startpos+11;i++){
				if(distance[22][i]<DRIBBLE_DISTANCE_SQUARE&&(players[i]._status<=PLAYER_RUN||players[i]._status==PLAYER_TACKLE)){
					int steal_lucky=random(0,100);
					float steal_possibility=(players[i]._aggression-football._holder->_dribble)*0.67+25;
					if(players[i]._status==PLAYER_TACKLE){
						steal_possibility+=10;
					}
					if(players[i]._side==SIDE_OPPO){//i just want to make the game balance~~
						steal_possibility+=25;
					}
					if(steal_lucky<steal_possibility){//can get the ball
						football._holder->_nextstatus=PLAYER_FALLREC;
						football._holder=&players[i];
						if(football._holder->_side==SIDE_ALLY){
							myplayer=football._holder;
						}
						side_attack=football._holder->_side;
						break;
					}
				}
			}
			//then check what he is doing to the ball
			if(football._holder->_status>PLAYER_RUN){
				if(football._holder->_status==PLAYER_PASS){
					if(football._holder->_action_moving._currentframe==3&&football._holder->_action_moving._timer==0){
						football._speed=football._holder->_charging_power/16;
						football._speedz=football._holder->_charging_power/15;
						football._rotation=football._holder->_rotation;//test
						football._previous_holder=football._holder;
						football._holder=NULL;
					}
				}else if(football._holder->_status==PLAYER_LOB){
					if(football._holder->_action_moving._currentframe==3&&football._holder->_action_moving._timer==0){
						football._speed=football._holder->_charging_power/16;
						football._speedz=football._holder->_charging_power/3;
						football._rotation=football._holder->_rotation;//test
						football._previous_holder=football._holder;
						football._holder=NULL;
					}
				}else if(football._holder->_status==PLAYER_THROUGHPASS){
					if(football._holder->_action_moving._currentframe==3&&football._holder->_action_moving._timer==0){
						football._speed=football._holder->_charging_power/16;
						football._speedz=football._holder->_charging_power/15;
						football._rotation=football._holder->_rotation;//test
						football._previous_holder=football._holder;
						football._holder=NULL;
					}
				}else if(football._holder->_status==PLAYER_SHOOT){
					if(football._holder->_action_moving._currentframe==3&&football._holder->_action_moving._timer==0){
						football._speed=football._holder->_charging_power/16;
						football._speedz=football._holder->_charging_power/7;//test should be adjust according to player shoot ability
						football._rotation=football._holder->_rotation;//test
						football._previous_holder=football._holder;
						football._holder=NULL;
					}
				}
			}
		}else{
			//check if anyone can get the ball
			int succpos=-1;
			if(football._z>=HEIGHT_PLAYER_REACHABLE||football._speed>SPEED_PLAYER_CATCHABLE) return;
			for(i=0;i<22;i++){
				if(distance[22][i]<DRIBBLE_DISTANCE_SQUARE&&(players[i]._status<=PLAYER_RUN||players[i]._status==PLAYER_TACKLE)&&(succpos<0||players[i]._aggression>players[succpos]._aggression)){
					succpos=i;
				}
			}
			if(succpos>=0){
				football._holder=&players[succpos];
				if(football._holder->_side==SIDE_ALLY){
					myplayer=football._holder;
				}
				side_attack=football._holder->_side;//!important
			}
		}
	}else{
		football._holder=NULL;
	}
/*	else if(football._status==BALL_GOAL_UP){*/
/*		//football._speed-=GROUND_FRICTION*3;*/
/*		//if(football._speed*/
/*	}else if(football._status==BALL_GOAL_DOWN){*/
/*		//ally_score+=1;*/
/*	}else if(football._status==BALL_OUT_LEFT){*/

/*	}else if(football._status==BALL_OUT_RIGHT){*/

/*	}else if(football._status==BALL_OUT_UP){*/

/*	}else if(football._status==BALL_OUT_DOWN){*/

/*	}*/
}
unsigned char get_direction(int deg){
	deg=deg%360;
	if(deg<0){deg+=360;}
	if((deg>=0&&deg<=45)||(deg>315&&deg<360)){
		return DIRE_UP;
	}else if(deg>45&&deg<=135){
		return DIRE_RIGHT;
	}else if(deg>135&&deg<=225){
		return DIRE_DOWN;		
	}
	return DIRE_LEFT;
}

void deg_approach(int * src,int dst,int delta){//make the source degree closer to the destination degree
	static int diff;
	diff=abs_int(*src-dst);
	if((diff<delta)||(360-diff)<delta){
		*src=dst;
		return;
	}
	if(dst>*src){
		if(dst-*src<180){
			*src=(*src+delta)%360;
		}else{
			*src=(*src-delta)%360;
		}
	}else if(*src>dst){
		if(*src-dst<180){
			*src=(*src-delta)%360;
		}else{
			*src=(*src+delta)%360;
		}
	}	
}

inline void get_ball_absposition(int * resx,int * resy){//football is in field
	*resx=football._x+field._x;
	*resy=football._y+field._y;
}

void update_player(struct Player * playersrc){
	if(playersrc->_status==PLAYER_RUN&&playersrc->_nextstatus!=PLAYER_RUN){
		playersrc->_action_moving._currentframe=0;
	}
	if(playersrc->_status==PLAYER_STAND||playersrc->_status==PLAYER_RUN||(playersrc->_action_moving._currentframe==0&&playersrc->_action_moving._timer==0)){//check if status can be updated
		playersrc->_status=playersrc->_nextstatus;
		playersrc->_nextstatus=PLAYER_STAND;//important
	}
	unsigned char current_direction=get_direction(playersrc->_rotation);
	if(playersrc->_status==PLAYER_STAND){
		playersrc->_speed=0;
		playersrc->_action_still._src=playersrc->_animation[playersrc->_status][current_direction];
	}else if(playersrc->_status==PLAYER_RUN){
		if(playersrc->_sprint==TRUE){
			if(playersrc->_speed<playersrc->_maxspeed/40){
				playersrc->_speed+=playersrc->_acceleration/100;
			}
		}else{
			if(playersrc->_speed<playersrc->_maxspeed/50){
				playersrc->_speed+=playersrc->_acceleration/100;
				if(playersrc->_speed>playersrc->_maxspeed/50){
					playersrc->_speed=playersrc->_acceleration/100;
				}
			}else{
				playersrc->_speed-=SPEED_DOWN_RATE;
				if(playersrc->_speed<0){playersrc->_speed=0;}
			}
		}
		deg_approach(&playersrc->_rotation,playersrc->_target_rotation,playersrc->_agility>>3);
		current_direction=get_direction(playersrc->_rotation);
		playersrc->_action_moving._image._src=playersrc->_animation[playersrc->_status][current_direction];
	}else if(playersrc->_status==PLAYER_PASS||playersrc->_status==PLAYER_THROUGHPASS||playersrc->_status==PLAYER_LOB||playersrc->_status==PLAYER_THROW||playersrc->_status==PLAYER_SHOOT){
		playersrc->_speed=0;
		playersrc->_action_moving._image._src=playersrc->_animation[playersrc->_status][current_direction];
	}else if(playersrc->_status==PLAYER_FALLREC){
		if(playersrc->_speed>0){
			playersrc->_speed-=SPEED_DOWN_RATE;
			if(playersrc->_speed<0){playersrc->_speed=0;}
		}
		playersrc->_action_moving._image._src=playersrc->_animation[playersrc->_status][current_direction];
	}else if(playersrc->_status==PLAYER_TACKLE){
		if(playersrc->_side!=side_attack){
			playersrc->_speed=playersrc->_maxspeed/35;
			playersrc->_action_moving._image._src=playersrc->_animation[playersrc->_status][current_direction];
		}
	}
	playersrc->_y += sin_deg(playersrc->_rotation)*playersrc->_speed;
	playersrc->_x -= cos_deg(playersrc->_rotation)*playersrc->_speed;
}

void update_ball(){
	if(football._holder!=NULL){
		football._y=football._holder->_y+sin_deg(football._holder->_rotation)*DRIBBLE_DISTANCE;
		football._x=football._holder->_x-cos_deg(football._holder->_rotation)*DRIBBLE_DISTANCE;
		football._speed=football._holder->_speed;
	}else{
		football._y+=sin_deg(football._rotation)*football._speed;
		football._x-=cos_deg(football._rotation)*football._speed;
		football._z+=football._speedz/16;
		if(football._z<0){
			football._z=0;
			football._speedz=football._speedz*(-0.7);
			if(abs_float(football._speedz)<0.2){
				football._speedz=0;
			}else{
			
			}
		}
		if(football._speed>0){
			if(football._z>0){
				football._speed-=AIR_FRICTION;
			}else{
				football._speed-=GROUND_FRICTION;
			}
		}
		if(football._speed<ZERO){
			football._speed=0;
		}
		if(football._z!=0){		
			football._speedz-=GRAVITY/8;
		}
		if(football._status==BALL_GOAL_UP){
			if(football._x<-27){
				football._x=-27;
				football._z=0;
				football._speedz=0;
			}
			if(football._y<DOOR_UP_LEFT){
				football._y=DOOR_UP_LEFT;
			}
			if(football._y>DOOR_UP_RIGHT){
				football._y=DOOR_UP_RIGHT;
			}
			if(football._speed==0){
				reset_stage(RESET_GOAL_UP);
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_GOAL_DOWN){
			if(football._x>827){
				football._x=827;
				football._z=0;
				football._speedz=0;
			}
			if(football._y<DOOR_DOWN_LEFT){
				football._y=DOOR_DOWN_LEFT;
			}
			if(football._y>DOOR_DOWN_RIGHT){
				football._y=DOOR_DOWN_RIGHT;
			}
			if(football._speed==0){
				reset_stage(RESET_GOAL_DOWN);
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_OUT_UP_LEFT){
			if(football._x<-57||football._speed==0){
				if(football._previous_holder->_side==SIDE_ALLY){
					reset_stage(RESET_GOALKICK_UP);
				}else{
					reset_stage(RESET_CORNER_UP_LEFT);
				}
			
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_OUT_UP_RIGHT){
			if(football._x<-57||football._speed==0){
				if(football._previous_holder->_side==SIDE_ALLY){
					reset_stage(RESET_GOALKICK_UP);
				}else{
					reset_stage(RESET_CORNER_UP_RIGHT);
				}
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_OUT_DOWN_LEFT){
			if(football._x>857||football._speed==0){
				if(football._previous_holder->_side==SIDE_ALLY){
					reset_stage(RESET_CORNER_DOWN_LEFT);
				}else{
					reset_stage(RESET_GOALKICK_DOWN);
				}
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_OUT_DOWN_RIGHT){
			if(football._x>857||football._speed==0){
				if(football._previous_holder->_side==SIDE_ALLY){
					reset_stage(RESET_CORNER_DOWN_RIGHT);
				}else{
					reset_stage(RESET_GOALKICK_DOWN);
				}
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_OUT_LEFT){
			if(football._y<-45||football._speed==0){
				reset_stage(RESET_SIDE_LEFT);
				football._status=BALL_NORMAL;
			}
		}else if(football._status==BALL_OUT_RIGHT){
			if(football._y>645||football._speed==0){
				reset_stage(RESET_SIDE_RIGHT);
				football._status=BALL_NORMAL;
			}
		}
	}
	if(football._status==BALL_NORMAL){
		if(football._x<0){
			if(football._y>DOOR_UP_LEFT&&football._y<DOOR_UP_RIGHT&&football._z<HEIGHT_DOOR_REACHABLE){
				ally_score+=1;
				football._status=BALL_GOAL_UP;
			}else if(football._y<302){
				football._status=BALL_OUT_UP_LEFT;
			}else{
				football._status=BALL_OUT_UP_RIGHT;
			}
			football._previous_holder=football._holder;
			football._holder=NULL;
		}else if(football._x>804){
			if(football._y>DOOR_DOWN_LEFT&&football._y<DOOR_DOWN_RIGHT&&football._z<HEIGHT_DOOR_REACHABLE){
				oppo_score+=1;
				football._status=BALL_GOAL_DOWN;
			}else if(football._y<302){
				football._status=BALL_OUT_DOWN_LEFT;
			}else{
				football._status=BALL_OUT_DOWN_RIGHT;
			}
			football._previous_holder=football._holder;
			football._holder=NULL;
		}else if(football._y<0){
			football._status=BALL_OUT_LEFT;
			football._previous_holder=football._holder;
			football._previous_x=football._x;
			football._holder=NULL;
		}else if(football._y>602){
			football._status=BALL_OUT_RIGHT;
			football._previous_holder=football._holder;
			football._previous_x=football._x;
			football._holder=NULL;
		}
	}

}
void update_background(){
	//if possible, keep football in the center
	static int field_target_x;
	static int field_target_y;
	field_target_x=100-football._x;
	field_target_y=160-football._y;
	if(field_target_x>57){
		field._x=57;
	}else if(field_target_x<-657){//-657=-(800+57-200)
		field._x=-657;
	}else{
		field._x=field_target_x;
	}
	if(field_target_y>45){
		field._y=45;
	}else if(field_target_y<-326){//-326=-(601+45-320)
		field._y=-326;
	}else{
		field._y=field_target_y;
	}
}

inline void draw_tempvmem(int x, int y, int color) {
	if ((x >= 0) && (y >= 0) && (x < resolution_x )&& (y < resolution_y)){
		/* this is a dialect of vmem[x * 320 + y] = color; */
		tempvmem[(x << 8 )+ (x << 6) + y] = color;
	}
}
void carry_to_vmem(){
	int i;
	for(i=0;i<resolution;i++){
		vmem[i] = tempvmem[i];
	}
}

inline void get_player_absposition(struct Player * player,int * resx,int * resy){//player is in field
	*resx=player->_x+field._x;
	*resy=player->_y+field._y;
}
inline unsigned char get_image_pixel(struct Image * imagesrc,int posx,int posy){
	if(posx<0||posx>=imagesrc->_height||posy<0||posy>=imagesrc->_width){return 0x00;}
	return imagesrc->_src[(posx*imagesrc->_width+posy)];
}

void draw_image(struct Image * imagesrc,int imagex,int imagey,struct Player * playersrc){
	//imagex & imagey here is absolute position!
	int image_startx;
	int image_starty;
	int stage_startx;
	int stage_starty;
	int draw_width;
	int draw_height;
	int i;
	int j;
	if(imagex<0){
		image_startx=-1*imagex;
		stage_startx=0;
	}else if(imagex<resolution_x){
		image_startx=0;
		stage_startx=imagex;
	}else{
		return;
	}
	if(imagey<0){
		image_starty=-1*imagey;
		stage_starty=0;
	}else if(imagey<resolution_y){
		image_starty=0;
		stage_starty=imagey;
	}else{
		return;
	}
	if(imagex+imagesrc->_height<=resolution_x){
		draw_height=imagesrc->_height-image_startx;
	}else{
		draw_height=resolution_x-stage_startx;
	}
	if(imagey+imagesrc->_width<=resolution_y){
		draw_width=imagesrc->_width-image_starty;
	}else{
		draw_width=resolution_y-stage_starty;
	}
	for(i=0;i<draw_height;i++){
		for(j=0;j<draw_width;j++){
			unsigned char color = get_image_pixel(imagesrc,image_startx+i,image_starty+j);
			if(color!=0xFF){//set 0xFF as invisible
				if(playersrc==NULL){
					draw_tempvmem(stage_startx+i,stage_starty+j,color);
					continue;
				}
				if(color==0x2C){//0x2C is default color of hair
					draw_tempvmem(stage_startx+i,stage_starty+j,playersrc->_hair_color);
				}else if(color==0xFB){//0xFB is default color of skin
					draw_tempvmem(stage_startx+i,stage_starty+j,playersrc->_skin_color);
				}else{
					draw_tempvmem(stage_startx+i,stage_starty+j,color);
				}
			}
			
		}
	}
}

void draw_imageclip(struct ImageClip * imageclipsrc,int imagex,int imagey,struct Player * playersrc){
	int clip_width=imageclipsrc->_image._width/imageclipsrc->_totalframe;
	int clip_height=imageclipsrc->_image._height;
	int image_startx;
	int image_starty;
	int stage_startx;
	int stage_starty;
	int draw_width;
	int draw_height;
	int i;
	int j;
	if(imagex<0){
		image_startx=-1*imagex;
		stage_startx=0;
	}else if(imagex<resolution_x){
		image_startx=0;
		stage_startx=imagex;
	}else{
		return;
	}
	if(imagey<0){
		image_starty=-1*imagey;
		stage_starty=0;
	}else if(imagey<resolution_y){
		image_starty=0;
		stage_starty=imagey;
	}else{
		return;
	}
	if(imagex+clip_height<=resolution_x){
		draw_height=clip_height-image_startx;
	}else{
		draw_height=resolution_x-stage_startx;
	}
	if(imagey+clip_width<=resolution_y){
		draw_width=clip_width-image_starty;
	}else{
		draw_width=resolution_y-stage_starty;
	}
	image_starty+=imageclipsrc->_currentframe*clip_width;

	for(i=0;i<draw_height;i++){
		for(j=0;j<draw_width;j++){
			unsigned char color = get_image_pixel(&imageclipsrc->_image,image_startx+i,image_starty+j);
			if(color!=0xFF){//set 0xFF as invisible
				if(playersrc==NULL){
					draw_tempvmem(stage_startx+i,stage_starty+j,color);
					continue;
				}
				if(color==0x2C){//0x2C is default color of hair
					draw_tempvmem(stage_startx+i,stage_starty+j,playersrc->_hair_color);
				}else if(color==0xFB){//0xFB is default color of skin
					draw_tempvmem(stage_startx+i,stage_starty+j,playersrc->_skin_color);
				}else{
					draw_tempvmem(stage_startx+i,stage_starty+j,color);
				}
			}
		}
	}
	
	imageclipsrc->_timer++;
	if(imageclipsrc->_timer<imageclipsrc->_interval) return;
	imageclipsrc->_timer=0;
	imageclipsrc->_currentframe=(imageclipsrc->_currentframe+1)%imageclipsrc->_totalframe;
	
}
void draw_background(){//draw first
	draw_image(&field._image,field._x+field._image._placex,field._y+field._image._placey,NULL);
}
struct Image door_down;
void draw_ball(){
	int absx;
	int absy;
	get_ball_absposition(&absx,&absy);
	if(football._speed<ZERO){
		draw_image(&football._action_still,absx+football._action_still._placex,absy+football._action_still._placey,NULL);
	}else{
		if(football._z<2){
			football._action_moving._image._width=32;
			football._action_moving._image._height=8;
			football._action_moving._image._src=acfootball_moving;
			draw_imageclip(&football._action_moving,absx-4,absy-4,NULL);
		}else if(football._z<4){
			football._action_moving._image._width=40;
			football._action_moving._image._height=10;
			football._action_moving._image._src=acfootball_5_moving;
			draw_imageclip(&football._action_moving,absx-5,absy-5,NULL);
		}else if(football._z<6){
			football._action_moving._image._width=48;
			football._action_moving._image._height=12;
			football._action_moving._image._src=acfootball_6_moving;
			draw_imageclip(&football._action_moving,absx-6,absy-6,NULL);
		}else{
			football._action_moving._image._width=56;
			football._action_moving._image._height=14;
			football._action_moving._image._src=acfootball_7_moving;
			draw_imageclip(&football._action_moving,absx-7,absy-7,NULL);
		}
	}
	//draw_imageclip(&football._clip_moving,absx+football._image._placex,absy+football._image._placey);
	//draw_image(&football._image,absx+football._image._placex,absy+football._image._placey);
}

void draw_player(struct Player * playersrc){
	static int absx;
	static int absy;
	static int i;
	static int j;
	get_player_absposition(playersrc,&absx,&absy);
	if(playersrc->_status==PLAYER_STAND){
		draw_image(&playersrc->_action_still,absx+playersrc->_action_still._placex,absy+playersrc->_action_still._placey,playersrc);
	}else{
		draw_imageclip(&playersrc->_action_moving,absx+playersrc->_action_moving._image._placex,absy+playersrc->_action_moving._image._placey,playersrc);
	}
	if(playersrc==myplayer){
		draw_image(&playersrc->_arrow,absx+playersrc->_arrow._placex,absy+playersrc->_arrow._placey,NULL);//draw arrow
	}
	if(playersrc->_action_charging!=PLAYER_NONE){//draw charging bar
		for(i=absx+2;i<absx+5;i++){
			for(j=absy-14;j<absy-playersrc->_charging_power/7;j++){
				draw_tempvmem(i,j,0x06);//charging bar background;
			}
			for(j=absy-playersrc->_charging_power/7;j<absy+playersrc->_charging_power/7;j++){
				draw_tempvmem(i,j,0x2C);//charging bar
			}
			for(j=absy+playersrc->_charging_power/7;j<absy+14;j++){
				draw_tempvmem(i,j,0x06);//charging bar background;
			}
		}
	}

}
void draw_text(const char * src,int startx,int starty,unsigned char color){
	int i=0;
	int j,k;
	int index;
	while(src[i]!='\0'){
		
		if(src[i]>='0'&&src[i]<='9'){
			index=src[i]-'0';
		}else if(src[i]>='A'&&src[i]<='Z'){
			index=src[i]-'A'+10;
		}else if(src[i]>='a'&&src[i]<='z'){
			index=src[i]-'a'+36;
		}else if(src[i]==':'){
			index=62;
		}else if(src[i]=='-'){
			index=63;
		}else if(src[i]=='_'){
			index=64;
		}else if(src[i]=='.'){
			index=65;
		}else if(src[i]==' '){
			index=0;
			i++;
			continue;
		}else{//that's all for now
			return;
		}
		
		for(j=0;j<11;j++){//11 is the size of font
			for(k=0;k<11;k++){
				unsigned char srccolor= acfont[800*j+11*index+k];
				if(srccolor!=0xFF){
					//i tried to use draw_tempvmem here but failed again and agian(QEMU always restart), so i have to assume that this won't go out of the screen
					int drawx=startx+j;
					int drawy=starty+k+11*i;
					tempvmem[(drawx<<8)+(drawx<<6)+drawy]=color;
				}
			}
		}
		i++;
	}
}
void draw_number(unsigned int number,int startx,int starty,unsigned char color){
	int i=0,j;
	char temp[10],swap;
	if(number==0){
		draw_text("0",startx,starty,color);
		return;
	}
	while(i<9&&number>0){
		temp[i]='0'+(number % 10);
		number/=10;
		i++;
	}
	for(j=0;j<=(i-1)/2;j++){
		swap=temp[j];
		temp[j]=temp[i-1-j];
		temp[i-1-j]=swap;
	}
	temp[i]='\0';
	
	draw_text(temp,startx,starty,color);
}
void sort_objects(){//use simple sort method because the amount is small
	int i,j;
	int ix,jx;
	struct ObjectPointer temp_object_pointer;
	for(i=0;i<23;i++){
		for(j=i+1;j<24;j++){
			if(objects[i]._type==TYPE_PLAYER){
				ix=((struct Player *)(objects[i]._src))->_x;
			}else if(objects[i]._type==TYPE_BALL){
				ix=((struct Ball *)(objects[i]._src))->_x;
			}else{
				ix=DOOR_DOWN;
			}
			if(objects[j]._type==TYPE_PLAYER){
				jx=((struct Player *)(objects[j]._src))->_x;
			}else if(objects[j]._type==TYPE_BALL){
				jx=((struct Ball *)(objects[j]._src))->_x;
			}else{
				jx=DOOR_DOWN;
			}
			if(ix>jx){
				temp_object_pointer._src=objects[j]._src;
				temp_object_pointer._type=objects[j]._type;
				objects[j]._src=objects[i]._src;
				objects[j]._type=objects[i]._type;
				objects[i]._src=temp_object_pointer._src;
				objects[i]._type=temp_object_pointer._type;
			}
		}
	}
	//adjust ball depth
	int ball_start=0;
	while(ball_start<24&&(objects[ball_start]._src!=&football)){
		ball_start++;
	}
	for(i=ball_start+1;i<24;i++){
		if(objects[i]._type==TYPE_PLAYER){
			ix=((struct Player *)(objects[i]._src))->_x;
			if(football._x>=ix-32&&football._x<=ix){
				if(football._z>HEIGHT_PLAYER_REACHABLE){
					temp_object_pointer._src=objects[i]._src;
					temp_object_pointer._type=objects[i]._type;
					objects[i]._src=objects[i-1]._src;
					objects[i]._type=objects[i-1]._type;
					objects[i-1]._src=temp_object_pointer._src;
					objects[i-1]._type=temp_object_pointer._type;
				}
			}else{
				break;
			}
		}else if(objects[i]._type==TYPE_DOOR){
			ix=DOOR_DOWN;
			if(football._x>=ix-50&&football._x<=ix){
				if(football._z>HEIGHT_DOOR_REACHABLE){
					temp_object_pointer._src=objects[i]._src;
					temp_object_pointer._type=objects[i]._type;
					objects[i]._src=objects[i-1]._src;
					objects[i]._type=objects[i-1]._type;
					objects[i-1]._src=temp_object_pointer._src;
					objects[i-1]._type=temp_object_pointer._type;
				}
			}else{
				break;
			}
		}
	}
}
void get_distances(){
	int i,j;
	static float desx,desy;
	for(i=0;i<21;i++){
		for(j=i+1;j<22;j++){
			desx=players[i]._x-players[j]._x;
			desy=players[i]._y-players[j]._y;
			distance[i][j]=desx*desx+desy*desy;
			distance[j][i]=distance[i][j];
		}
	}
	for(i=0;i<22;i++){
		desx=players[i]._x-football._x;
		desy=players[i]._y-football._y;
		distance[i][22]=desx*desx+desy*desy;
		distance[22][i]=distance[i][22];
	}
}

void
init_game(void) {
	
	int i=0;
	for(i=0;i<256;i++){
		key_pressdown[i]=FALSE;
	}
	game_status=GAME_SELECT;
	//define team data here
	teams[0]._team=TEAM_MANCHESTER;
	my_strcpy("Manchester United",teams[0]._name,100);
	teams[0]._clothes_color=0x28;
	teams[0]._pants_color=0x0F;
	teams[0]._stripe_color=0x28;
	teams[0]._sleeve_color=0x28;
	teams[0]._player_attributesrc[0]=&PA_DE_GEA;
	teams[0]._player_attributesrc[1]=&PA_C_SMALLING;
	teams[0]._player_attributesrc[2]=&PA_R_FERDINAND;
	teams[0]._player_attributesrc[3]=&PA_N_VIDIC;
	teams[0]._player_attributesrc[4]=&PA_P_EVRA;
	teams[0]._player_attributesrc[5]=&PA_J_PARK;
	teams[0]._player_attributesrc[6]=&PA_NANI;
	teams[0]._player_attributesrc[7]=&PA_A_YOUNG;
	teams[0]._player_attributesrc[8]=&PA_ANDERSON;
	teams[0]._player_attributesrc[9]=&PA_J_HERNANDEZ;
	teams[0]._player_attributesrc[10]=&PA_W_ROONEY;
	
	teams[1]._team=TEAM_CHELSEA;
	my_strcpy("Chelsea",teams[1]._name,100);
	teams[1]._clothes_color=0x37;
	teams[1]._pants_color=0x37;
	teams[1]._stripe_color=0x37;
	teams[1]._sleeve_color=0x0F;
	teams[1]._player_attributesrc[0]=&PA_P_CECH;
	teams[1]._player_attributesrc[1]=&PA_JOSE_BOSINGWA;
	teams[1]._player_attributesrc[2]=&PA_B_IVANOVIC;
	teams[1]._player_attributesrc[3]=&PA_J_TERRY;
	teams[1]._player_attributesrc[4]=&PA_A_COLE;
	teams[1]._player_attributesrc[5]=&PA_J_MIKEL;
	teams[1]._player_attributesrc[6]=&PA_RAMIRES;
	teams[1]._player_attributesrc[7]=&PA_MATA;
	teams[1]._player_attributesrc[8]=&PA_F_LAMPARD;
	teams[1]._player_attributesrc[9]=&PA_FERNANDO_TORRES;
	teams[1]._player_attributesrc[10]=&PA_D_DROGBA;
	
	teams[2]._team=TEAM_MILAN;
	my_strcpy("AC Milan",teams[2]._name,100);
	teams[2]._clothes_color=0x28;
	teams[2]._pants_color=0x0F;
	teams[2]._stripe_color=0x00;
	teams[2]._sleeve_color=0x28;
	teams[2]._player_attributesrc[0]=&PA_C_ABBIATI;
	teams[2]._player_attributesrc[1]=&PA_I_ABATE;
	teams[2]._player_attributesrc[2]=&PA_A_NESTA;
	teams[2]._player_attributesrc[3]=&PA_THIAGO_SILVA;
	teams[2]._player_attributesrc[4]=&PA_T_TAIWO;
	teams[2]._player_attributesrc[5]=&PA_M_AMBROSINI;
	teams[2]._player_attributesrc[6]=&PA_M_VAN_BOMMEL;
	teams[2]._player_attributesrc[7]=&PA_A_AQUILANI;
	teams[2]._player_attributesrc[8]=&PA_K_BOATENG;
	teams[2]._player_attributesrc[9]=&PA_ALEXANDRE_PATO;
	teams[2]._player_attributesrc[10]=&PA_Z_IBRAHIMOVIC;

	teams[3]._team=TEAM_INTER;
	my_strcpy("Inter Milan",teams[3]._name,100);
	teams[3]._clothes_color=0x36;
	teams[3]._pants_color=0x00;
	teams[3]._stripe_color=0x00;
	teams[3]._sleeve_color=0x36;
	teams[3]._player_attributesrc[0]=&PA_JULIO_CESAR;
	teams[3]._player_attributesrc[1]=&PA_MAICON;
	teams[3]._player_attributesrc[2]=&PA_LUCIO;
	teams[3]._player_attributesrc[3]=&PA_W_SAMUEL;
	teams[3]._player_attributesrc[4]=&PA_C_CHIVU;
	teams[3]._player_attributesrc[5]=&PA_J_ZANETTI;
	teams[3]._player_attributesrc[6]=&PA_E_CAMBIASSO;
	teams[3]._player_attributesrc[7]=&PA_D_STANKOVIC;
	teams[3]._player_attributesrc[8]=&PA_W_SNEIJDER;
	teams[3]._player_attributesrc[9]=&PA_G_PAZZINI;
	teams[3]._player_attributesrc[10]=&PA_D_FORLAN;
	
	teams[4]._team=TEAM_BARCELONA;
	my_strcpy("FC Barcelona",teams[4]._name,100);
	teams[4]._clothes_color=0x21;
	teams[4]._pants_color=0x21;
	teams[4]._stripe_color=0x23;
	teams[4]._sleeve_color=0x23;
	teams[4]._player_attributesrc[0]=&PA_VALDES;
	teams[4]._player_attributesrc[1]=&PA_DANI_ALVES;
	teams[4]._player_attributesrc[2]=&PA_PUYOL;
	teams[4]._player_attributesrc[3]=&PA_PIQUE;
	teams[4]._player_attributesrc[4]=&PA_E_ABIDAL;
	teams[4]._player_attributesrc[5]=&PA_SERGIO_BUSQUETS;
	teams[4]._player_attributesrc[6]=&PA_XAVI;
	teams[4]._player_attributesrc[7]=&PA_INIESTA;
	teams[4]._player_attributesrc[8]=&PA_CESC_FABREGAS;
	teams[4]._player_attributesrc[9]=&PA_L_MESSI;
	teams[4]._player_attributesrc[10]=&PA_DAVID_VILLA;
	
	teams[5]._team=TEAM_BAYERN;
	my_strcpy("Bayern Munchen",teams[5]._name,100);
	teams[5]._clothes_color=0x28;
	teams[5]._pants_color=0x28;
	teams[5]._stripe_color=0x0F;
	teams[5]._sleeve_color=0x28;
	teams[5]._player_attributesrc[0]=&PA_M_NEUER;
	teams[5]._player_attributesrc[1]=&PA_P_LAHM;
	teams[5]._player_attributesrc[2]=&PA_J_BOATENG;
	teams[5]._player_attributesrc[3]=&PA_H_BADSTUBER;
	teams[5]._player_attributesrc[4]=&PA_RAFINHA;
	teams[5]._player_attributesrc[5]=&PA_LUIZ_GUSTAVO;
	teams[5]._player_attributesrc[6]=&PA_B_SCHWEINSTEIGER;
	teams[5]._player_attributesrc[7]=&PA_A_ROBBEN;
	teams[5]._player_attributesrc[8]=&PA_T_MULLER;
	teams[5]._player_attributesrc[9]=&PA_F_RIBERY;
	teams[5]._player_attributesrc[10]=&PA_M_GOMEZ;

	//init game
	ally_score=0;
	oppo_score=0;
	ally_team=TEAM_MILAN;
	oppo_team=TEAM_INTER;
	
	football._basex=400;
	football._basey=302;
	football._x=football._basex;
	football._y=football._basey;
	football._speed=0;
	football._speedz=0;
	football._curve=0;
	football._radius=4;
	football._action_still._src=acfootball_still;
	football._action_still._width=8;
	football._action_still._height=8;
	football._action_still._placex=-football._action_still._height/2;
	football._action_still._placey=-football._action_still._width/2;
	football._action_moving._image._src=acfootball_moving;
	football._action_moving._image._width=32;
	football._action_moving._image._height=8;
	football._action_moving._image._placex=-4;
	football._action_moving._image._placey=-4;
	football._action_moving._totalframe=4;
	football._action_moving._currentframe=0;
	football._action_moving._interval=1;
	football._action_moving._timer=0;
	//field._parent=NULL;
	field._x=100-football._x;//init
	field._y=160-football._y;//init
	field._width=601;
	field._height=800;
	field._image._src=acplayground;
	field._image._width=692;
	field._image._height=923;
	field._image._placex=-57;
	field._image._placey=-45;
	door_down._src=acdoor_down;
	door_down._width=200;
	door_down._height=84;
	door_down._placex=-49;
	door_down._placey=0;
	generate_field();
	
	
	side_attack=SIDE_ALLY;
	//set initial position
	//top 11
	players[11]._basex=16;
	players[11]._basey=302;
	players[12]._basex=158;
	players[12]._basey=74;
	players[13]._basex=141;
	players[13]._basey=213;
	players[14]._basex=150;
	players[14]._basey=396;
	players[15]._basex=181;
	players[15]._basey=506;
	players[16]._basex=199;
	players[16]._basey=271;
	players[17]._basex=263;
	players[17]._basey=148;
	players[18]._basex=266;
	players[18]._basey=414;
	players[19]._basex=309;
	players[19]._basey=266;
	players[20]._basex=377;
	players[20]._basey=192;
	players[21]._basex=378;
	players[21]._basey=333;
	//bottom 11
	players[0]._basex=785;
	players[0]._basey=302;
	players[1]._basex=651;
	players[1]._basey=494;
	players[2]._basex=670;
	players[2]._basey=339;
	players[3]._basex=667;
	players[3]._basey=206;
	players[4]._basex=636;
	players[4]._basey=58;
	players[5]._basex=604;
	players[5]._basey=288;
	players[6]._basex=559;
	players[6]._basey=422;
	players[7]._basex=556;
	players[8]._basey=135;
	players[8]._basex=508;
	players[8]._basey=297;
	players[9]._basex=455;
	players[9]._basey=363;
	players[10]._basex=456;
	players[10]._basey=241;
	//init players
	//ally
	for(i=0;i<11;i++){

		players[i]._side=SIDE_ALLY;
		players[i]._rotation=0;//test
		players[i]._action_still._src=ally_stand_down;
		players[i]._action_moving._image._src=ally_run_down;
		players[i]._animation[0][0]=ally_stand_up;
		players[i]._animation[0][1]=ally_stand_down;
		players[i]._animation[0][2]=ally_stand_left;
		players[i]._animation[0][3]=ally_stand_right;
		players[i]._animation[1][0]=ally_run_up;
		players[i]._animation[1][1]=ally_run_down;
		players[i]._animation[1][2]=ally_run_left;
		players[i]._animation[1][3]=ally_run_right;
		players[i]._animation[2][0]=ally_pass_up;
		players[i]._animation[2][1]=ally_pass_down;
		players[i]._animation[2][2]=ally_pass_left;
		players[i]._animation[2][3]=ally_pass_right;
		players[i]._animation[3][0]=ally_lob_up;
		players[i]._animation[3][1]=ally_lob_down;
		players[i]._animation[3][2]=ally_lob_left;
		players[i]._animation[3][3]=ally_lob_right;
		players[i]._animation[4][0]=ally_throw_up;
		players[i]._animation[4][1]=ally_throw_down;
		players[i]._animation[4][2]=ally_throw_left;
		players[i]._animation[4][3]=ally_throw_right;
		players[i]._animation[5][0]=ally_fallrec_up;
		players[i]._animation[5][1]=ally_fallrec_down;
		players[i]._animation[5][2]=ally_fallrec_left;
		players[i]._animation[5][3]=ally_fallrec_right;
		players[i]._animation[6][0]=ally_tackle_up;
		players[i]._animation[6][1]=ally_tackle_down;
		players[i]._animation[6][2]=ally_tackle_left;
		players[i]._animation[6][3]=ally_tackle_right;
		players[i]._animation[7][0]=ally_lob_up;
		players[i]._animation[7][1]=ally_lob_down;
		players[i]._animation[7][2]=ally_lob_left;
		players[i]._animation[7][3]=ally_lob_right;
		players[i]._animation[8][0]=ally_pass_up;
		players[i]._animation[8][1]=ally_pass_down;
		players[i]._animation[8][2]=ally_pass_left;
		players[i]._animation[8][3]=ally_pass_right;
	}
	//oppo
	for(i=11;i<22;i++){
		players[i]._side=SIDE_OPPO;
		players[i]._rotation=180;//test	
		players[i]._action_still._src=oppo_stand_down;
		players[i]._action_moving._image._src=oppo_run_down;
		players[i]._animation[0][0]=oppo_stand_up;
		players[i]._animation[0][1]=oppo_stand_down;
		players[i]._animation[0][2]=oppo_stand_left;
		players[i]._animation[0][3]=oppo_stand_right;
		players[i]._animation[1][0]=oppo_run_up;
		players[i]._animation[1][1]=oppo_run_down;
		players[i]._animation[1][2]=oppo_run_left;
		players[i]._animation[1][3]=oppo_run_right;
		players[i]._animation[2][0]=oppo_pass_up;
		players[i]._animation[2][1]=oppo_pass_down;
		players[i]._animation[2][2]=oppo_pass_left;
		players[i]._animation[2][3]=oppo_pass_right;
		players[i]._animation[3][0]=oppo_lob_up;
		players[i]._animation[3][1]=oppo_lob_down;
		players[i]._animation[3][2]=oppo_lob_left;
		players[i]._animation[3][3]=oppo_lob_right;
		players[i]._animation[4][0]=oppo_throw_up;
		players[i]._animation[4][1]=oppo_throw_down;
		players[i]._animation[4][2]=oppo_throw_left;
		players[i]._animation[4][3]=oppo_throw_right;
		players[i]._animation[5][0]=oppo_fallrec_up;
		players[i]._animation[5][1]=oppo_fallrec_down;
		players[i]._animation[5][2]=oppo_fallrec_left;
		players[i]._animation[5][3]=oppo_fallrec_right;
		players[i]._animation[6][0]=oppo_tackle_up;
		players[i]._animation[6][1]=oppo_tackle_down;
		players[i]._animation[6][2]=oppo_tackle_left;
		players[i]._animation[6][3]=oppo_tackle_right;
		players[i]._animation[7][0]=oppo_lob_up;
		players[i]._animation[7][1]=oppo_lob_down;
		players[i]._animation[7][2]=oppo_lob_left;
		players[i]._animation[7][3]=oppo_lob_right;
		players[i]._animation[8][0]=oppo_pass_up;
		players[i]._animation[8][1]=oppo_pass_down;
		players[i]._animation[8][2]=oppo_pass_left;
		players[i]._animation[8][3]=oppo_pass_right;
	}
	//common
	for(i=0;i<22;i++){
		players[i]._x=players[i]._basex;
		players[i]._y=players[i]._basey;
		players[i]._sprint=FALSE;
		players[i]._speed=0;//test
		players[i]._status=PLAYER_STAND;
		players[i]._nextstatus=players[i]._status;
		players[i]._action_charging=PLAYER_NONE;
		players[i]._charging_power=0;
		players[i]._task=TASK_NONE;
		players[i]._threat=0;
		players[i]._mark_target=NULL;
		players[i]._arrow._src=acarrow_down;
		players[i]._arrow._width=6;
		players[i]._arrow._height=6;
		players[i]._arrow._placex=-39;
		players[i]._arrow._placey=-4;
		players[i]._action_still._width=32;
		players[i]._action_still._height=32;
		players[i]._action_still._placex=-players[i]._action_still._height;
		players[i]._action_still._placey=-players[i]._action_still._width/2;	
		players[i]._action_moving._image._width=256;
		players[i]._action_moving._image._height=32;
		players[i]._action_moving._image._placex=-32;
		players[i]._action_moving._image._placey=-16;
		players[i]._action_moving._totalframe=8;
		players[i]._action_moving._currentframe=random(0,2);
		players[i]._action_moving._interval=2;
		players[i]._action_moving._timer=random(0,2);
	}
	//both side use 4-1-2-1-2 formation
	players[0]._role=ROLE_GK;
	players[1]._role=ROLE_RB;
	players[2]._role=ROLE_CB;
	players[3]._role=ROLE_CB;
	players[4]._role=ROLE_LB;
	players[5]._role=ROLE_CDM;
	players[6]._role=ROLE_RM;
	players[7]._role=ROLE_LM;
	players[8]._role=ROLE_CAM;
	players[9]._role=ROLE_ST;
	players[10]._role=ROLE_CF;
	players[11]._role=ROLE_GK;
	players[12]._role=ROLE_RB;
	players[13]._role=ROLE_CB;
	players[14]._role=ROLE_CB;
	players[15]._role=ROLE_LB;
	players[16]._role=ROLE_CDM;
	players[17]._role=ROLE_RM;
	players[18]._role=ROLE_LM;
	players[19]._role=ROLE_CAM;
	players[20]._role=ROLE_ST;
	players[21]._role=ROLE_CF;
	//set player color
	
	//set pointer to image and imageclip
	
	football._holder=&players[10];
	myplayer=&players[10];
	players[10]._x=football._x;
	players[10]._y=football._y-8;
	players[10]._rotation=90;
	players[9]._x=football._x;
	players[9]._y=football._y+8;
	players[9]._rotation=270;
	for(i=0;i<22;i++){
		objects[i]._src=&players[i];
		objects[i]._type=TYPE_PLAYER;
	}
	objects[22]._src=&football;
	objects[22]._type=TYPE_BALL;
	objects[23]._src=NULL;
	objects[23]._type=TYPE_DOOR;
	
}

inline void change_rand_seed(){
	rand_seed=rand_seed+1+myplayer->_x+myplayer->_y;
}
void team_select(){
	int i;
	static int select_count=0;
	static int start_light=0;//blink!!!
	
	if(key_isdown(KEY_S)){
		generate_ally_color(&teams[ally_team]);
		generate_oppo_color(&teams[oppo_team]);
		for(i=0;i<11;i++){
			generate_player(teams[ally_team]._player_attributesrc[i],&players[i]);
		}
		for(i=11;i<22;i++){
			generate_player(teams[oppo_team]._player_attributesrc[i-11],&players[i]);
		}
		game_status=GAME_RUN;
	}
	
	select_count++;
	if(select_count<8) return;//limit the switch speed
	
	select_count=0;
	start_light++;
	for(i=0;i<resolution;i++){
		tempvmem[i]=0x0F;//draw background
	}
	if(key_isdown(KEY_UP)){
		oppo_team=(oppo_team+1)%TEAM_COUNT;	
	}else if(key_isdown(KEY_DOWN)){
		if(oppo_team==0){
			oppo_team=TEAM_COUNT-1;
		}else{
			oppo_team=(oppo_team-1)%TEAM_COUNT;
		}		
	}else if(key_isdown(KEY_RIGHT)){
		ally_team=(ally_team+1)%TEAM_COUNT;	
	}else if(key_isdown(KEY_LEFT)){
		if(ally_team==0){
			ally_team=TEAM_COUNT-1;
		}else{
			ally_team=(ally_team-1)%TEAM_COUNT;
		}			
	}
	draw_text("F",10,100,0x00);
	draw_text("A",10,111,0x34);
	draw_text("F",10,122,0x00);
	draw_text("I",10,133,0x2C);
	
	draw_text("12    by zmz",10,155,0x00);

	//draw_text("FAFI 12 by zmz",10,10,0x00);
	draw_text("PLAYER TEAM:",40,10,0x00);
	draw_text("LEFT or RIGHT to SELECT",55,10,0x00);
	draw_text(teams[ally_team]._name,80,10,0x2F);
	draw_text("COMPUTER TEAM:",110,10,0x00);
	draw_text("UP or DOWN to SELECT",125,10,0x00);
	draw_text(teams[oppo_team]._name,150,10,0x28);
	if(start_light>=10){
		start_light=0;
	}
	if(start_light>=5){
		draw_text("S TO START",180,90,0x35);
	}
	carry_to_vmem();
}
void
start_frame(void) {
	static int frame_timer = 0;
	
	int i,j;
	frame_timer++;
	if(frame_timer<FRAME_INTERVAL) return;//limit FPS to about 30
	frame_timer=0;
	if(game_status==GAME_SELECT){
		team_select();
		return;
	}
	/* Game Logic */
	change_rand_seed();//change random seed every frame to make it more random
	sort_objects();
	get_distances();
	//first, draw current frame, then analysis, then calculate the next frame
	/* Draw Begin */
	draw_background();
	//draw objects ordered by depth
	//draw_image(&door_down,field._x+753,field._y+199,NULL);
	for(i=0;i<24;i++){
		if(objects[i]._type==TYPE_PLAYER){
			draw_player(objects[i]._src);
		}else if(objects[i]._type==TYPE_BALL){
			draw_ball();
		}else{
			draw_image(&door_down,field._x+753,field._y+199,NULL);
		}
	}
	
	//draw score board
	for(i=10;i<25;i++){
		for(j=10;j<69;j++){
			draw_tempvmem(i,j,0x29);
		}
	}
	//draw score
	draw_number(ally_score,12,23,0x0F);
	draw_text(":",12,34,0x0F);
	draw_number(oppo_score,12,45,0x0F);
	//draw the name of the current controlled player
	draw_text(myplayer->_name,187,2,0x0F);
			
	carry_to_vmem();//carry tempvmem To vmem
	/* Draw End */
	/* Analysis Begin */
	controll_my_player_action();
	controll_my_player_direction();
	controll_AI_players();
	controll_ball();
	/* Analysis End */
	/* Calculate Begin */
	for(i=0;i<22;i++){
		update_player(&players[i]);
	}
	
	update_ball();
	update_background();
	/* Calculate End */
	
	
	
}

void
key_stroke(int code) {//handle keyboard interupt
	if(code<128){
		key_pressdown[code]=TRUE;
	}else{
		key_pressdown[code-128]=FALSE;
	}
}








